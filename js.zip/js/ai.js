// ============ AI 动作审查（网页版） ============
// 流程：训练视频 → 自动抓 4 个关键帧 → 连同「博主标准发力要点」发给视觉大模型
//      → 返回结构化报告：总评分 / 发力差异 / 问题点 / 改进建议
//
// 兼容 OpenAI Chat Completions 协议的任意多模态模型（通义千问 / 智谱 GLM / Kimi / DeepSeek 等）
// 配置入口：我的 → 设置 → AI 动作审查
// 网页版没有域白名单限制，配好 Key 即用

const PROVIDERS = [
  {
    id: 'qwen',
    name: '通义千问',
    baseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1',
    model: 'qwen-vl-max',
    hint: '阿里云百炼控制台获取 API Key'
  },
  {
    id: 'zhipu',
    name: '智谱 GLM',
    baseUrl: 'https://open.bigmodel.cn/api/paas/v4',
    model: 'glm-4v-plus',
    hint: '智谱 AI 开放平台获取 API Key'
  },
  {
    id: 'kimi',
    name: 'Kimi 视觉',
    baseUrl: 'https://api.moonshot.cn/v1',
    model: 'moonshot-v1-8k-vision-preview',
    hint: 'Moonshot 开放平台获取 API Key'
  },
  {
    id: 'custom',
    name: '自定义',
    baseUrl: '',
    model: '',
    hint: '任意兼容 OpenAI 协议的多模态服务'
  }
]

function getVendorById(id) {
  return PROVIDERS.find(p => p.id === id) || PROVIDERS[0]
}

// ---------- 抓取视频关键帧（15% / 40% / 65% / 88% 时间点） ----------
// 返回 base64 数组（jpeg，最长边 640）
function grabFrames(blob, count) {
  count = count || 4
  return new Promise(async (resolve, reject) => {
    const url = URL.createObjectURL(blob)
    const video = document.createElement('video')
    video.muted = true
    video.playsInline = true
    video.preload = 'auto'
    video.src = url

    const cleanup = () => { URL.revokeObjectURL(url) }
    const fail = (msg) => { cleanup(); reject(new Error(msg || '视频读取失败')) }

    video.onerror = () => fail('视频格式无法解析，请换 MP4/MOV 格式')
    try {
      await new Promise((ok, no) => {
        video.onloadedmetadata = ok
        setTimeout(() => no(new Error('加载超时')), 15000)
      })
    } catch (e) { fail(e.message); return }

    const dur = video.duration
    if (!isFinite(dur) || dur <= 0.5) { fail('视频时长太短，抓不到帧'); return }

    const canvas = document.createElement('canvas')
    const ctx = canvas.getContext('2d')
    const pts = [0.15, 0.4, 0.65, 0.88].slice(0, count)
      .map(p => Math.max(0.1, Math.min(dur - 0.1, dur * p)))

    const frames = []
    const seekTo = (t) => new Promise((ok) => {
      const onSeeked = () => {
        video.removeEventListener('seeked', onSeeked)
        setTimeout(ok, 150) // 等帧真正渲染
      }
      video.addEventListener('seeked', onSeeked)
      video.currentTime = t
    })

    try {
      for (const t of pts) {
        await seekTo(t)
        const vw = video.videoWidth, vh = video.videoHeight
        if (!vw || !vh) continue
        const maxSide = 640
        const r = Math.min(1, maxSide / Math.max(vw, vh))
        canvas.width = Math.round(vw * r)
        canvas.height = Math.round(vh * r)
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height)
        frames.push(canvas.toDataURL('image/jpeg', 0.7).replace(/^data:image\/\w+;base64,/, ''))
      }
    } catch (e) {
      cleanup(); reject(new Error('抓帧失败：' + e.message)); return
    }
    cleanup()
    if (!frames.length) { reject(new Error('没有抓到任何画面')); return }
    resolve(frames)
  })
}

// ---------- 构造对比提示词 ----------
function buildPrompt(ex, gender) {
  const range = gender === 'female' ? ex.female : ex.male
  const rangeText = range ? range[0] + '-' + range[1] + ex.unit : '自重'
  return [
    '你是一位有十年经验的健身教练，现在要审查学员的训练动作视频截图。',
    '',
    '【动作】' + ex.name + '（' + ex.sets + '组 × ' + ex.reps + (ex.unit === '次' ? '次' : ex.unit) + '，建议重量 ' + rangeText + '）',
    '【目标肌群】' + (ex.muscle || '见动作要领'),
    '【网络博主的发力标准】' + (ex.stdMind || ex.tips),
    '【标准节奏】' + (ex.stdTempo || '匀速控制，不借力'),
    '【该动作常见偏差】' + (ex.devi || ex.errors),
    '',
    '请仔细观察这几张视频截图，按以下 JSON 格式输出审查报告（不要输出任何其他文字，不要用 markdown 代码块）：',
    '{',
    '  "score": 数字(0-100的动作质量评分),',
    '  "level": "优秀/良好/合格/需改进 四选一",',
    '  "summary": "一句话总体评价，不超过30字",',
    '  "diffs": [{"point":"对比博主标准的差异点","detail":"具体描述你从图片看到的"}],',
    '  "issues": [{"title":"问题名称","severity":"高/中/低","detail":"为什么是问题，会导致什么"}],',
    '  "suggestions": [{"title":"改进动作","detail":"下次训练具体怎么做"}],',
    '  "match": 数字(0-100, 与博主标准发力的相似度)',
    '}',
    '',
    '要求：diffs 至少 2 条，issues 至少 2 条，suggestions 至少 2 条。',
    '若因截图角度或清晰度无法判断某个部位，请如实说明「该角度看不清，建议下次侧向拍摄」，不要凭空编造。'
  ].join('\n')
}

// ---------- 调用视觉模型 ----------
async function callVisionModel(frames, prompt) {
  const cfg = getAiConfig()
  if (!cfg.apiKey) throw { code: 'NO_KEY', msg: '尚未配置 API Key，请到 设置 → AI 动作审查 填写' }

  const content = [{ type: 'text', text: prompt }]
  frames.forEach(b64 => {
    content.push({ type: 'image_url', image_url: { url: 'data:image/jpeg;base64,' + b64 } })
  })

  let res
  try {
    res = await fetch(cfg.baseUrl.replace(/\/$/, '') + '/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + cfg.apiKey
      },
      body: JSON.stringify({
        model: cfg.model,
        messages: [{ role: 'user', content }],
        temperature: 0.3
      })
    })
  } catch (e) {
    throw { code: 'NETWORK', msg: '网络请求失败，请检查网络或接口地址' }
  }

  if (!res.ok) {
    let msg = '服务返回 ' + res.status
    try {
      const err = await res.json()
      if (err && err.error && err.error.message) msg = err.error.message
    } catch (e) { }
    throw { code: 'HTTP_' + res.status, msg }
  }

  const data = await res.json()
  try {
    const text = data.choices[0].message.content
    return parseReport(text)
  } catch (e) {
    throw { code: 'PARSE', msg: '返回内容解析失败，请重试或换个模型' }
  }
}

// ---------- 容错解析 ----------
function parseReport(text) {
  if (!text) throw new Error('empty')
  let t = String(text).trim()
  t = t.replace(/^```(?:json)?/i, '').replace(/```$/, '').trim()
  const start = t.indexOf('{'), end = t.lastIndexOf('}')
  if (start >= 0 && end > start) t = t.slice(start, end + 1)
  const obj = JSON.parse(t)
  return {
    score: Math.max(0, Math.min(100, parseInt(obj.score) || 0)),
    level: obj.level || '合格',
    summary: obj.summary || '',
    diffs: Array.isArray(obj.diffs) ? obj.diffs : [],
    issues: Array.isArray(obj.issues) ? obj.issues : [],
    suggestions: Array.isArray(obj.suggestions) ? obj.suggestions : [],
    match: Math.max(0, Math.min(100, parseInt(obj.match) || 0))
  }
}

// ---------- 测试连接 ----------
async function testAiConnection() {
  const cfg = getAiConfig()
  if (!cfg.apiKey) throw { code: 'NO_KEY', msg: '请先填写 API Key' }
  let res
  try {
    res = await fetch(cfg.baseUrl.replace(/\/$/, '') + '/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + cfg.apiKey
      },
      body: JSON.stringify({
        model: cfg.model,
        messages: [{ role: 'user', content: '回复"OK"两个字母即可' }],
        max_tokens: 8
      })
    })
  } catch (e) {
    throw { code: 'NETWORK', msg: '连不上接口地址，请检查网络' }
  }
  if (!res.ok) {
    let msg = '服务返回 ' + res.status
    try {
      const err = await res.json()
      if (err && err.error && err.error.message) msg = err.error.message
    } catch (e) { }
    throw { code: 'HTTP_' + res.status, msg }
  }
  return true
}

// ---------- 主入口 ----------
async function review(ex, frames, gender) {
  const prompt = buildPrompt(ex, gender)
  return callVisionModel(frames, prompt)
}
