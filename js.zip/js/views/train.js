// ============ 训练模块：周视图 / 训练执行 / 动作详情 ============

// ---------- 周视图 ----------
App.views.train = {
  render(el, params) {
    const today = todayStr()
    const sel = params.d || today
    const plan = getPlanByDate(sel)
    const isToday = sel === today
    const checked = !!getCheckin(sel)

    // 7 天 chips（本周）
    const dow = weekDayOf(today)
    const mondayOffset = dow === 0 ? -6 : 1 - dow
    const chips = []
    for (let i = 0; i < 7; i++) {
      const ds = addDays(today, mondayOffset + i)
      const p = PLAN[weekDayOf(ds)]
      const cls = p.type === 'rest' ? 'rest-chip' : (p.type === 'stretch' ? 'stretch-chip' : '')
      chips.push(
        '<div class="chip ' + cls + (ds === sel ? ' active' : '') + '" onclick="App.go(\'train?d=' + ds + '\')">' +
        dayName(ds).replace('周', '') +
        '<span class="t">' + (p.type === 'rest' ? '休' : p.type === 'stretch' ? '拉' : '练') + '</span>' +
        '</div>'
      )
    }

    let body = ''
    if (plan.type === 'rest') {
      body =
        '<div class="card" style="text-align:center;padding:26px 18px">' +
        '<div style="font-size:44px">' + plan.emoji + '</div>' +
        '<div style="font-size:18px;font-weight:900;margin-top:8px">' + plan.title + '</div>' +
        '<div class="muted mt8">' + plan.desc + '</div>' +
        '</div>' +
        '<div class="card">' +
        '<div class="card-title">🎬 休息日推荐视频</div>' +
        this.videoList(['休息日放松', '练后拉伸']) +
        '</div>'
    } else {
      const exs = (plan.exercises || []).map((ex, i) => {
        const range = getProfile().gender === 'female' ? ex.female : ex.male
        const rangeText = range ? range[0] + ' - ' + range[1] + ex.unit : '自重'
        return (
          '<div class="row-item" onclick="App.go(\'exercise?id=' + ex.id + '\')" style="cursor:pointer">' +
          '<div class="ri-ic">' + ['💪', '🔥', '🦵', '⭐'][i % 4] + '</div>' +
          '<div class="ri-main">' +
          '<div class="ri-title">' + esc(ex.name) + '</div>' +
          '<div class="ri-sub">建议 ' + rangeText + ' · ' + ex.sets + ' 组 × ' + ex.reps + ex.unit + '</div>' +
          '</div>' +
          '<div class="ri-right"><div class="b1">›</div></div>' +
          '</div>'
        )
      }).join('')

      body =
        '<div class="card">' +
        '<div class="flex">' +
        '<div class="pt" style="font-size:19px;font-weight:900">' + plan.emoji + ' ' + plan.title + '</div>' +
        (checked ? '<span class="tag green" style="margin-left:auto">已打卡 ✓</span>' : '') +
        '</div>' +
        '<div class="muted small mt8">专注：' + plan.focus + '</div>' +
        (plan.cardio ? '<div class="hint-box mt12">🏃 有氧收尾：' + esc(plan.cardio.name) + ' · ' + esc(plan.cardio.detail) + '</div>' : '') +
        '<div class="mt12">' + exs + '</div>' +
        (isToday && !checked
          ? '<button class="btn primary block" onclick="App.go(\'train-run\')">▶ 开始今日训练</button>'
          : isToday
            ? '<div class="flex"><button class="btn green block" onclick="App.go(\'train-run\')">补充记录</button></div>'
            : '<div class="muted small" style="text-align:center">这不是今天的训练日，只能回顾哦</div>') +
        '</div>'
    }

    el.innerHTML =
      '<div class="chip-row">' + chips.join('') + '</div>' +
      body

    this.bindTeach(el)
  },

  videoList(cats) {
    return VIDEO_LIB.filter(v => cats.indexOf(v.cat) >= 0).slice(0, 4).map(v =>
      '<div class="row-item" data-teach="' + v.id + '" style="cursor:pointer">' +
      '<div class="ri-ic">🎞️</div>' +
      '<div class="ri-main"><div class="ri-title">' + esc(v.title) + '</div>' +
      '<div class="ri-sub">' + esc(v.cat) + ' · ' + esc(v.note) + '</div></div>' +
      '<div class="ri-right"><div class="b1">▶</div></div>' +
      '</div>'
    ).join('')
  },

  bindTeach(scope) {
    scope.querySelectorAll('[data-teach]').forEach(r => {
      r.onclick = () => {
        const v = VIDEO_LIB.find(x => x.id === r.dataset.teach)
        if (!v) return
        App.modal({
          title: '▶ ' + esc(v.title),
          body: '<video src="' + v.url + '" controls playsinline style="width:100%;border-radius:14px;border:3px solid #2B2B2B;background:#2B2B2B"></video>' +
            '<div class="muted small" style="margin-top:8px">' + esc(v.note) + ' · ' + v.dur + '</div>',
          buttons: [{ text: '关闭', cls: 'primary' }]
        })
      }
    })
  }
}

// ---------- 训练执行页 ----------
App.views['train-run'] = {
  _tid: null,
  _state: null,

  render(el) {
    const plan = getTodayPlan()
    const today = todayStr()

    if (plan.type === 'rest') {
      el.innerHTML = '<div class="empty"><span class="e-ic">🛌</span>今天是休息日，肌肉在生长，去散散步吧</div>'
      return
    }

    const gender = (getProfile().gender || 'male')
    const todayRec = getTrainRecord(today)
    const exercises = (plan.exercises || []).map(ex => {
      const hist = getExerciseHistory(ex.id, today)
      let lastText = null, lastDate = '', todayText = null
      if (hist) {
        lastText = hist.sets.map(s => (s.weight ? s.weight + 'kg×' : '') + s.reps).join(' / ')
        lastDate = hist.date
      }
      // 今天已练过这个动作 → 显示今天的数据
      const exToday = todayRec && (todayRec.exercises || []).find(e => e.id === ex.id)
      if (exToday) {
        todayText = '✅ 今天已练：' + exToday.sets.map(s => (s.weight ? s.weight + 'kg×' : '') + s.reps).join(' / ')
      }
      const sug = ex.male ? suggestNextWeight(ex, today) : null
      return Object.assign({}, ex, { lastText, lastDate, todayText, suggest: sug, groups: [], doneCount: 0 })
    })

    this._state = {
      plan, today, exercises, gender,
      timer: { running: false, remain: 90, len: 90 }
    }
    exercises.forEach(ex => { for (let i = 0; i < ex.sets; i++) ex.groups.push({ weight: '', reps: '', done: false }) })

    const exHtml = exercises.map((ex, ei) => {
      const rows = ex.groups.map((g, gi) =>
        '<div class="set-row" data-ei="' + ei + '" data-gi="' + gi + '">' +
        '<div class="sn' + (g.done ? ' done' : '') + '">' + (g.done ? '✓' : gi + 1) + '</div>' +
        '<input type="number" inputmode="decimal" placeholder="重量" ' + (ex.male ? '' : 'disabled value="—" style="opacity:.35"') + '>' +
        '<span class="x">×</span>' +
        '<input type="number" inputmode="numeric" placeholder="次数" >' +
        '<button class="check-btn ' + (g.done ? 'done' : '') + '">' + (g.done ? '✓' : '完成') + '</button>' +
        '</div>'
      ).join('')
      return (
        '<div class="ex-item" data-ei="' + ei + '">' +
        '<div class="ex-head">' +
        '<span class="ex-name">' + esc(ex.name) + '</span>' +
        '<span class="ex-sub">' + ex.sets + '×' + ex.reps + ex.unit + '</span>' +
        '<span class="arrow">›</span>' +
        '</div>' +
        '<div class="ex-body" style="display:none">' +
        (ex.todayText
          ? '<div class="hint-box" style="background:#E8F4DD">' + ex.todayText + '</div>'
          : ex.lastText
            ? '<div class="hint-box last">🕓 上次(' + friendly(ex.lastDate) + ')：' + ex.lastText + '</div>'
            : '<div class="hint-box last">🆕 首次训练，先找基线：能标准完成 ' + ex.reps + ' 次的最后两组略吃力，就是合适的重量</div>') +
        (ex.suggest ? '<div class="hint-box suggest">📈 渐进超负荷：上次全部达标，建议加重至 <b>' + ex.suggest.nextWeight + ex.unit + '</b></div>' : '') +
        '<div class="sets-box">' + rows + '</div>' +
        '<button class="btn sm blue" data-jump="' + ex.id + '">🎥 看教学</button>' +
        '</div></div>'
      )
    }).join('')

    el.innerHTML =
      '<div class="hint-box">' + plan.emoji + ' 今日：' + plan.title + '。点动作名展开，逐组填「重量×次数」，完成一组自动开始组间计时</div>' +
      exHtml +
      '<button class="btn primary block" id="end-btn" style="margin-top:4px">🏁 结束训练并打卡</button>' +
      '<div id="timer-float">' +
      '<div><div class="t-left">01:30</div><div class="t-label">组间休息</div></div>' +
      '<div class="t-opts"><button data-sec="60">60s</button><button data-sec="90" class="on">90s</button><button data-sec="120">120s</button></div>' +
      '<button class="t-stop">跳过</button>' +
      '</div>'

    // 交互绑定
    const tfloat = el.querySelector('#timer-float')

    el.querySelectorAll('.ex-head').forEach(h => {
      h.onclick = () => {
        const item = h.parentElement
        const open = item.classList.toggle('open')
        item.querySelector('.ex-body').style.display = open ? 'block' : 'none'
      }
    })
    // 展开第一个
    const first = el.querySelector('.ex-item')
    if (first) { first.classList.add('open'); first.querySelector('.ex-body').style.display = 'block' }

    el.querySelectorAll('.set-row .check-btn').forEach(btn => {
      btn.onclick = (e) => {
        e.stopPropagation()
        const row = btn.closest('.set-row')
        const ei = +row.dataset.ei, gi = +row.dataset.gi
        const st = this._state
        const ex = st.exercises[ei]
        const g = ex.groups[gi]
        if (g.done) return
        const reps = parseFloat(row.querySelectorAll('input')[1].value)
        const weight = parseFloat(row.querySelectorAll('input')[0].value)
        if (!reps || reps <= 0) { App.toast('先填次数'); return }
        if (ex.male && (!weight || weight <= 0)) { App.toast('器械动作要填重量'); return }
        g.done = true; g.weight = weight; g.reps = reps
        row.querySelector('.sn').classList.add('done')
        row.querySelector('.sn').textContent = '✓'
        btn.classList.add('done'); btn.textContent = '✓'
        if (navigator.vibrate) navigator.vibrate(60)
        // 全组完成 → 折叠，展开下一个
        ex.doneCount++
        if (ex.doneCount >= ex.sets) {
          const item = row.closest('.ex-item')
          item.classList.remove('open')
          item.querySelector('.ex-body').style.display = 'none'
          const next = this._state.exercises.findIndex(x => x.doneCount < x.sets)
          if (next >= 0) {
            const nItem = el.querySelectorAll('.ex-item')[next]
            nItem.classList.add('open')
            nItem.querySelector('.ex-body').style.display = 'block'
          }
        }
        this.startTimer(st.timer.len, tfloat)
      }
    })

    el.querySelectorAll('[data-jump]').forEach(b => {
      b.onclick = (e) => { e.stopPropagation(); App.go('exercise?id=' + b.dataset.jump) }
    })

    // 计时器
    tfloat.querySelectorAll('.t-opts button').forEach(b => {
      b.onclick = () => {
        tfloat.querySelectorAll('.t-opts button').forEach(x => x.classList.remove('on'))
        b.classList.add('on')
        this._state.timer.len = +b.dataset.sec
        if (this._state.timer.running) this.startTimer(+b.dataset.sec, tfloat)
      }
    })
    tfloat.querySelector('.t-stop').onclick = () => this.stopTimer(tfloat)

    el.querySelector('#end-btn').onclick = () => this.endTrain(el)
  },

  // ---------- 计时器 ----------
  startTimer(sec, tfloat) {
    const st = this._state
    this.stopTimer(tfloat)
    st.timer.running = true
    st.timer.remain = sec
    const show = () => {
      const m = Math.floor(st.timer.remain / 60), s = st.timer.remain % 60
      tfloat.querySelector('.t-left').textContent = (m < 10 ? '0' + m : m) + ':' + (s < 10 ? '0' + s : s)
    }
    show()
    tfloat.classList.add('show')
    document.body.classList.add('timer-open')
    this._tid = setInterval(() => {
      st.timer.remain--
      if (st.timer.remain <= 0) {
        this.stopTimer(tfloat)
        if (navigator.vibrate) navigator.vibrate([120, 80, 120])
        App.toast('休息结束，该你了！💪')
      } else show()
    }, 1000)
  },

  stopTimer(tfloat) {
    clearInterval(this._tid)
    this._tid = null
    if (this._state) this._state.timer.running = false
    document.body.classList.remove('timer-open')
    if (tfloat) tfloat.classList.remove('show')
  },

  onLeave() {
    clearInterval(this._tid)
    this._tid = null
  },

  // ---------- 结束训练 ----------
  endTrain(el) {
    const st = this._state
    if (!st) return
    const recExercises = st.exercises
      .map(ex => ({
        id: ex.id, name: ex.name,
        sets: ex.groups.filter(g => g.done).map(g => ({ weight: g.weight || 0, reps: g.reps || 0 }))
      }))
      .filter(e => e.sets.length > 0)

    if (!recExercises.length) { App.toast('至少完成一组才能结束'); return }

    let volume = 0
    recExercises.forEach(e => e.sets.forEach(s => { volume += s.weight * s.reps }))
    const totalGroups = recExercises.reduce((s, e) => s + e.sets.length, 0)

    saveTrainRecord(st.today, {
      planTitle: st.plan.title,
      type: st.plan.type,
      exercises: recExercises,
      totalVolume: volume
    })
    doCheckin(st.today, { type: st.plan.type, title: st.plan.title })
    this.stopTimer(el.querySelector('#timer-float'))

    const volText = volume > 0 ? '，总容量 <b>' + Math.round(volume) + '</b> kg' : ''
    App.modal({
      title: st.plan.type === 'stretch' ? '🧘 拉伸完成' : '💪 训练完成',
      body: '共完成 <b>' + totalGroups + '</b> 组' + volText + '，已打卡 ✓<br><br>要拍一段视频记录今天的生活吗？',
      buttons: [
        { text: '不了', cls: '' },
        {
          text: '📷 拍视频', cls: 'primary', cb: async () => {
            const f = await App.pickVideo()
            if (!f) { App.toast('已跳过'); App.go('home'); return }
            App.modal({ title: '⏳ 保存中', body: '<div class="loading-dots"><i></i><i></i><i></i></div>', noClose: true })
            try {
              await App.saveVideoFile(f, {
                name: st.plan.title + ' · ' + friendly(st.today),
                date: st.today,
                type: 'checkin'
              })
              App.closeModal()
              App.modal({
                title: '✅ 视频已保存到本地',
                body: '要顺便下载一份到手机相册/电脑吗？换设备也不丢。',
                buttons: [
                  { text: '不用' },
                  {
                    text: '⬇️ 下载备份', cls: 'blue', cb: async () => {
                      const vids = getVideos()
                      await App.downloadVideo(vids[0].id, vids[0].name)
                    }
                  }
                ]
              })
            } catch (e) {
              App.closeModal()
              App.toast('保存失败：' + (e.message || '存储空间不足'))
            }
            setTimeout(() => App.go('home'), 600)
          }
        }
      ]
    })
    // 更新按钮状态（重新渲染由路由切换完成，这里先简单禁用）
    el.querySelector('#end-btn').disabled = true
    setTimeout(() => App.go('home'), 100)
  }
}

// ---------- 动作详情页 ----------
App.views.exercise = {
  render(el, params) {
    const ex = getAllExercises().find(e => e.id === params.id)
    if (!ex) { el.innerHTML = '<div class="empty">动作不存在</div>'; return }
    const profile = getProfile()
    const gender = profile.gender || 'male'
    const range = gender === 'female' ? ex.female : ex.male
    const rangeText = range ? range[0] + ' - ' + range[1] + ex.unit : '自重'

    const vids = VIDEO_LIB.slice(0, 3)
    const vHtml = vids.map(v =>
      '<div class="row-item" data-teach="' + v.id + '" style="cursor:pointer">' +
      '<div class="ri-ic">🎞️</div><div class="ri-main"><div class="ri-title">' + esc(v.title) + '</div></div>' +
      '<div class="ri-right"><div class="b1">▶</div></div></div>'
    ).join('')

    el.innerHTML =
      '<div class="card">' +
      '<div class="flex"><div class="pt" style="font-size:20px;font-weight:900">' + esc(ex.name) + '</div></div>' +
      '<div class="flex mt12" style="flex-wrap:wrap;gap:6px">' +
      '<span class="tag red">' + ex.sets + ' 组 × ' + ex.reps + ex.unit + '</span>' +
      '<span class="tag yellow">建议 ' + rangeText + '</span>' +
      '<span class="tag blue">' + esc(ex.muscle || '') + '</span>' +
      '</div>' +
      '<div class="hint-box mt12">🎯 目标肌群：' + esc(ex.muscle) + '</div>' +
      '</div>' +

      '<div class="card">' +
      '<div class="card-title">✍️ 动作要领</div>' +
      '<div style="font-size:14px;line-height:1.75">' + esc(ex.tips) + '</div>' +
      '<div class="hint-box mt12" style="background:#FFE9E6">⚠️ 常见错误：' + esc(ex.errors) + '</div>' +
      '<div class="hint-box" style="background:#E9F0FD">🥁 标准节奏：' + esc(ex.stdTempo || '匀速控制') + '</div>' +
      '</div>' +

      '<div class="card">' +
      '<div class="card-title">🎬 教学视频</div>' + vHtml +
      '<div class="muted small" style="margin-top:4px">* 演示源为公开 CC0 视频，可替换成博主教学</div>' +
      '</div>' +

      '<div class="card">' +
      '<div class="card-title">🤖 AI 动作自查</div>' +
      '<div class="muted small">拍一段自己训练的视频，AI 会对比博主的发力标准，指出差异和改进点</div>' +
      '<div class="btn-row"><button class="btn primary block" id="go-review">📷 去拍 / 上传视频自查</button></div>' +
      '</div>'

    el.querySelector('#go-review').onclick = () => App.go('review?ex=' + ex.id)
    App.views.train.bindTeach(el)
  }
}
