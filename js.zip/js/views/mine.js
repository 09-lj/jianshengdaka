// ============ 我的 / 日历 / 日记 / 设置 ============

// ---------- 我的 ----------
App.views.mine = {
  render(el) {
    const profile = getProfile()
    const s = getStats()
    const badges = calcBadges()
    const body = getBodyList()
    const water = getWaterToday()
    const waterGoal = profile.waterGoal || 8

    // 体重折线（SVG）
    let chart = '<div class="muted small" style="text-align:center;padding:18px 0">记录 ' + (body.length) + ' 次后开始画趋势</div>'
    const weights = body.filter(b => b.weight)
    if (weights.length >= 2) {
      const w = 320, h = 110, pad = 8
      const vals = weights.map(b => b.weight)
      const min = Math.min.apply(null, vals), max = Math.max.apply(null, vals)
      const span = (max - min) || 1
      const pts = weights.map((b, i) => {
        const x = pad + (w - pad * 2) * (i / (weights.length - 1))
        const y = h - pad - (h - pad * 2) * ((b.weight - min) / span)
        return [x, y, b]
      })
      const line = pts.map(p => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ')
      const last = pts[pts.length - 1]
      const diff = weights[weights.length - 1].weight - weights[0].weight
      chart =
        '<div class="chart-box"><svg viewBox="0 0 ' + w + ' ' + h + '">' +
        '<polyline points="' + line + '" fill="none" stroke="#E23B2E" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>' +
        pts.map(p => '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="4.5" fill="#FFFDF6" stroke="#2B2B2B" stroke-width="2.5"/>').join('') +
        '</svg></div>' +
        '<div class="flex mt8"><span class="muted small">' + weights[0].weight + 'kg → <b style="color:var(--primary)">' + last[2].weight + 'kg</b></span>' +
        '<span class="tag ' + (diff <= 0 ? 'green' : 'yellow') + '" style="margin-left:auto">' + (diff <= 0 ? '▼' : '▲') + ' ' + Math.abs(Math.round(diff * 10) / 10) + 'kg</span></div>'
    } else if (weights.length === 1) {
      chart = '<div class="hint-box">当前体重：' + weights[0].weight + 'kg（' + friendly(weights[0].date) + '），再记一次就能看趋势</div>'
    }

    el.innerHTML =
      '<div class="card flex">' +
      '<img src="images/cover.jpg" style="width:56px;height:56px;border:3px solid #2B2B2B;border-radius:18px;box-shadow:3px 4px 0 #2B2B2B;object-fit:cover">' +
      '<div><div style="font-weight:900;font-size:17px">' + esc(profile.nickname || '健身新人') + '</div>' +
      '<div class="muted small">' + (profile.gender === 'female' ? '👧 女生计划' : '👦 男生计划') + ' · 连续打卡 ' + s.streak + ' 天 🔥</div></div>' +
      '<button class="btn sm" style="margin-left:auto" onclick="App.go(\'settings\')">⚙️ 设置</button>' +
      '</div>' +

      '<div class="stat-grid">' +
      '<div class="stat-cell"><div class="v">' + s.streak + '</div><div class="k">连续打卡</div></div>' +
      '<div class="stat-cell"><div class="v">' + s.totalTrain + '</div><div class="k">总训练次数</div></div>' +
      '<div class="stat-cell"><div class="v">' + s.videos + '</div><div class="k">训练视频</div></div>' +
      '</div>' +

      '<div class="card">' +
      '<div class="card-title">⚖️ 身体数据 <span class="more">' + (body.length ? '最近 ' + friendly(body[body.length - 1].date) : '') + '</span></div>' +
      chart +
      '<div class="btn-row"><button class="btn primary block" id="add-body">＋ 记录今天体重</button></div>' +
      '</div>' +

      '<div class="card">' +
      '<div class="card-title">💧 今日饮水 <span class="more">' + water + ' / ' + waterGoal + ' 杯</span></div>' +
      '<div class="water-grid" id="water-grid"></div>' +
      '</div>' +

      '<div class="card">' +
      '<div class="card-title">🏅 徽章（' + badges.filter(b => b.got).length + '/' + badges.length + '）</div>' +
      '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px">' +
      badges.map(b =>
        '<div style="text-align:center;border:2.5px solid ' + (b.got ? '#2B2B2B' : '#D8D2C0') + ';border-radius:14px;padding:8px 2px;' + (b.got ? 'background:#FFF;box-shadow:2px 3px 0 #2B2B2B' : 'opacity:.45') + '">' +
        '<div style="font-size:20px">' + b.icon + '</div>' +
        '<div style="font-size:10.5px;font-weight:900">' + b.name + '</div></div>'
      ).join('') + '</div></div>' +

      '<div class="card" style="padding:0">' +
      '<div class="drawer-item" style="border:none;box-shadow:none;border-radius:0;border-bottom:3px dashed #E5DFD0;margin:0" onclick="App.go(\'calendar\')">📅 打卡日历<span style="margin-left:auto">›</span></div>' +
      '<div class="drawer-item" style="border:none;box-shadow:none;border-radius:0;border-bottom:3px dashed #E5DFD0;margin:0" onclick="App.go(\'diary\')">📖 训练日记<span style="margin-left:auto">›</span></div>' +
      '<div class="drawer-item" style="border:none;box-shadow:none;border-radius:0;border-bottom:3px dashed #E5DFD0;margin:0" onclick="App.go(\'media\')">🎬 视频管理<span style="margin-left:auto">›</span></div>' +
      '<div class="drawer-item" style="border:none;box-shadow:none;border-radius:0;margin:0" onclick="App.go(\'about\')">ℹ️ 关于<span style="margin-left:auto">›</span></div>' +
      '</div>'

    // 添加身体数据
    el.querySelector('#add-body').onclick = () => {
      App.modal({
        title: '⚖️ 记录身体数据',
        body:
          '<div class="form-row"><label>体重（kg）<span class="fv">今天</span></label><input id="bd-weight" type="number" inputmode="decimal" placeholder="如 68.5"></div>' +
          '<div class="form-row" style="margin-bottom:0"><label>体脂率（%，可留空）</label><input id="bd-fat" type="number" inputmode="decimal" placeholder="如 22"></div>',
        buttons: [
          { text: '取消' },
          {
            text: '保存', cls: 'primary', cb: () => {
              const weight = parseFloat(document.getElementById('bd-weight').value)
              const fat = parseFloat(document.getElementById('bd-fat').value)
              if (!weight || weight <= 0) { App.toast('请填写体重'); return false }
              addBodyRecord({ date: todayStr(), weight, fat: fat || null })
              App.toast('已记录 ✓')
              App.route()
            }
          }
        ]
      })
    }

    // 饮水
    const grid = el.querySelector('#water-grid')
    const renderCups = () => {
      const n = getWaterToday()
      let html = ''
      for (let i = 1; i <= 12; i++) {
        html += '<div class="cup ' + (i <= n ? 'full' : '') + '" data-n="' + i + '">' + (i <= n ? '💧' : '🥛') + '</div>'
      }
      grid.innerHTML = html
      grid.querySelectorAll('.cup').forEach(c => {
        c.onclick = () => {
          const n = +c.dataset.n
          const cur = getWaterToday()
          setWaterCups(cur === n ? n - 1 : n)
          renderCups()
          if (getWaterToday() >= waterGoal) App.toast('今日饮水达标 💧')
        }
      })
    }
    renderCups()
  }
}

// ---------- 打卡日历 ----------
App.views.calendar = {
  _ym: null,

  render(el) {
    if (!this._ym) {
      const now = new Date()
      this._ym = { y: now.getFullYear(), m: now.getMonth() + 1 }
    }
    const { y, m } = this._ym
    const days = getMonthCheckins(y, m)
    const firstDow = weekDayOf(y + '-' + pad(m) + '-01')
    const today = todayStr()

    let cells = ['日', '一', '二', '三', '四', '五', '六'].map(h => '<div class="cal-hd">' + h + '</div>').join('')
    for (let i = 0; i < firstDow; i++) cells += '<div></div>'
    days.forEach(d => {
      const plan = PLAN[weekDayOf(d.date)]
      const cls = ['cal-cell']
      if (plan.type !== 'rest') cls.push('on-plan', plan.type === 'train' ? 'train-day' : '')
      if (d.checkin) cls.push('done')
      if (d.date === today) cls.push('today')
      cells += '<div class="' + cls.join(' ') + '">' + d.day + '</div>'
    })

    const stats = get(KEY.CHECKIN, {})
    const monthDays = days.filter(d => d.checkin).length

    el.innerHTML =
      '<div class="card">' +
      '<div class="flex" style="justify-content:space-between">' +
      '<button class="btn sm" id="cal-prev">‹ 上月</button>' +
      '<div style="font-weight:900;font-size:17px">' + y + ' 年 ' + m + ' 月</div>' +
      '<button class="btn sm" id="cal-next">下月 ›</button>' +
      '</div>' +
      '<div class="cal-grid mt12">' + cells + '</div>' +
      '<div class="flex mt12" style="justify-content:center;gap:10px" >' +
      '<span class="muted small">本月打卡 <b style="color:var(--green)">' + monthDays + '</b> 天</span>' +
      '<span class="muted small">·</span>' +
      '<span class="muted small">🟩 已打卡</span>' +
      '<span class="muted small">⬜ 训练日</span>' +
      '</div></div>'

    el.querySelector('#cal-prev').onclick = () => {
      let { y, m } = this._ym
      m--; if (m === 0) { m = 12; y-- }
      this._ym = { y, m }
      this.render(el)
    }
    el.querySelector('#cal-next').onclick = () => {
      let { y, m } = this._ym
      m++; if (m === 13) { m = 1; y++ }
      this._ym = { y, m }
      this.render(el)
    }
  }
}

// ---------- 训练日记 ----------
App.views.diary = {
  render(el) {
    const all = get(KEY.TRAIN, {})
    const dates = Object.keys(all).sort().reverse()

    if (!dates.length) {
      el.innerHTML = '<div class="empty"><span class="e-ic">📖</span>还没有训练记录<br>完成第一次训练后，这里就是你的成长日记</div>'
      return
    }

    const cards = dates.map(ds => {
      const rec = all[ds]
      const exs = (rec.exercises || []).map(e => {
        const setsText = e.sets.map(s2 => (s2.weight ? s2.weight + 'kg×' : '') + s2.reps).join(' / ')
        return '<div class="hint-box" style="margin-bottom:8px"><b>' + esc(e.name) + '</b> · ' + setsText + '</div>'
      }).join('')
      return (
        '<div class="card">' +
        '<div class="flex">' +
        '<div style="font-weight:900">' + friendly(ds) + ' ' + dayName(ds) + '</div>' +
        '<span class="tag ' + (rec.type === 'stretch' ? 'blue' : 'red') + '" style="margin-left:auto">' + esc(rec.planTitle) + '</span>' +
        '</div>' +
        (rec.totalVolume ? '<div class="muted small mt8">总容量 ' + Math.round(rec.totalVolume) + ' kg</div>' : '') +
        '<div class="mt12">' + exs + '</div>' +
        '</div>'
      )
    }).join('')

    el.innerHTML = cards
  }
}

// ---------- 设置 ----------
App.views.settings = {
  render(el) {
    const profile = getProfile()
    const cfg = getAiConfig()

    const providerOpts = PROVIDERS.map(p =>
      '<option value="' + p.id + '"' + (cfg.vendor === p.id ? ' selected' : '') + '>' + p.name + '</option>'
    ).join('')

    el.innerHTML =
      '<div class="card">' +
      '<div class="card-title">👤 个人资料</div>' +
      '<div class="form-row"><label>昵称</label><input id="st-nick" value="' + esc(profile.nickname || '') + '"></div>' +
      '<div class="form-row"><label>性别 <span class="fv">决定动作的建议重量区间</span></label>' +
      '<div class="seg">' +
      '<button class="seg-btn ' + (profile.gender !== 'female' ? 'on' : '') + '" data-g="male">👦 男生</button>' +
      '<button class="seg-btn ' + (profile.gender === 'female' ? 'on' : '') + '" data-g="female">👧 女生</button>' +
      '</div></div>' +
      '<div class="form-row"><label>每日热量目标（kcal）</label><input id="st-kcal" type="number" value="' + (profile.targetKcal || 1800) + '"></div>' +
      '<div class="form-row"><label>每日蛋白质目标（g）</label><input id="st-pro" type="number" value="' + (profile.targetProtein || 120) + '"></div>' +
      '<div class="form-row" style="margin-bottom:0"><label>每日饮水目标（杯）</label><input id="st-water" type="number" value="' + (profile.waterGoal || 8) + '"></div>' +
      '<div class="btn-row"><button class="btn primary block" id="st-save">保存资料</button></div>' +
      '</div>' +

      '<div class="card">' +
      '<div class="card-title">🤖 AI 动作审查</div>' +
      '<div class="muted small" style="margin-bottom:12px">配置一个支持「图片理解」的大模型 API Key，训练视频就能被 AI 逐帧审查，对比博主发力标准。网页版无域名限制，配好即用</div>' +
      '<div class="form-row"><label>服务商</label><select id="ai-vendor">' + providerOpts + '</select></div>' +
      '<div class="form-row"><label>接口地址 <span class="fv">baseUrl</span></label><input id="ai-url" value="' + esc(cfg.baseUrl) + '"></div>' +
      '<div class="form-row"><label>模型名</label><input id="ai-model" value="' + esc(cfg.model) + '"></div>' +
      '<div class="form-row" style="margin-bottom:0"><label>API Key <span class="fv">仅存在本机浏览器，不会上传</span></label>' +
      '<input id="ai-key" type="password" value="' + esc(cfg.apiKey) + '" placeholder="sk-..."></div>' +
      '<div class="btn-row">' +
      '<button class="btn blue" id="ai-test">测试连接</button>' +
      '<button class="btn primary" id="ai-save">保存配置</button>' +
      '</div>' +
      '<div class="hint-box mt12" id="ai-hint" style="margin-bottom:0">💡 ' + esc(getVendorById(cfg.vendor).hint) + '</div>' +
      '</div>' +

      '<div class="card">' +
      '<div class="card-title">🗑️ 数据管理</div>' +
      '<div class="muted small">所有数据（打卡 / 记录 / 视频）都保存在这台设备的浏览器里，不上云、不联网同步</div>' +
      '<div class="btn-row"><button class="btn block" id="st-clear" style="border-color:#E23B2E;color:#E23B2E">清除全部数据</button></div>' +
      '</div>' +

      '<div class="card">' +
      '<div class="card-title">ℹ️ 关于</div>' +
      '<div class="muted small" style="line-height:1.8">炼打卡 · 网页版 v1.0<br>周一三五分化训练 + 周六拉伸的纯本地健身打卡应用<br>插画为 AI 生成的原创蜡笔风格（非官方蜡笔小新形象，如商用请注意版权）</div>' +
      '</div>'

    // 性别切换
    el.querySelectorAll('[data-g]').forEach(b => {
      b.onclick = () => {
        el.querySelectorAll('[data-g]').forEach(x => x.classList.remove('on'))
        b.classList.add('on')
      }
    })

    // 资料保存
    el.querySelector('#st-save').onclick = () => {
      const gender = el.querySelector('[data-g].on').dataset.g
      updateProfile({
        nickname: el.querySelector('#st-nick').value.trim() || '健身新人',
        gender,
        targetKcal: Math.max(800, +el.querySelector('#st-kcal').value || 1800),
        targetProtein: Math.max(30, +el.querySelector('#st-pro').value || 120),
        waterGoal: Math.max(4, +el.querySelector('#st-water').value || 8)
      })
      App.toast('已保存 ✓')
    }

    // AI 服务商联动
    el.querySelector('#ai-vendor').onchange = (e) => {
      const p = getVendorById(e.target.value)
      el.querySelector('#ai-url').value = p.baseUrl
      el.querySelector('#ai-model').value = p.model
      el.querySelector('#ai-hint').innerHTML = '💡 ' + esc(p.hint)
    }

    el.querySelector('#ai-save').onclick = () => {
      updateAiConfig({
        vendor: el.querySelector('#ai-vendor').value,
        baseUrl: el.querySelector('#ai-url').value.trim(),
        model: el.querySelector('#ai-model').value.trim(),
        apiKey: el.querySelector('#ai-key').value.trim()
      })
      App.toast('AI 配置已保存 ✓')
    }

    el.querySelector('#ai-test').onclick = async () => {
      // 先保存再测试
      updateAiConfig({
        vendor: el.querySelector('#ai-vendor').value,
        baseUrl: el.querySelector('#ai-url').value.trim(),
        model: el.querySelector('#ai-model').value.trim(),
        apiKey: el.querySelector('#ai-key').value.trim()
      })
      App.toast('测试中…')
      try {
        await testAiConnection()
        App.modal({ title: '✅ 连接成功', body: '模型可用，去「AI 动作审查」试试吧', buttons: [{ text: '好', cls: 'primary' }] })
      } catch (e) {
        App.modal({ title: '❌ 连接失败', body: esc(e.msg || '未知错误'), buttons: [{ text: '知道了', cls: 'primary' }] })
      }
    }

    // 清除数据
    el.querySelector('#st-clear').onclick = () => {
      App.modal({
        title: '⚠️ 确认清除全部数据？',
        body: '打卡、训练记录、身体数据、<b>所有视频</b>都会被删除，且无法恢复。建议先把重要视频下载备份',
        buttons: [
          { text: '取消' },
          {
            text: '全部删除', cls: 'primary', cb: async () => {
              await clearAll()
              App.toast('已清空')
              App.go('home')
              App.route()
            }
          }
        ]
      })
    }
  }
}

// ---------- 关于 ----------
App.views.about = {
  render(el) {
    el.innerHTML =
      '<div class="card" style="text-align:center">' +
      '<img src="images/cover.jpg" style="width:110px;border:4px solid #2B2B2B;border-radius:26px;box-shadow:4px 5px 0 #2B2B2B">' +
      '<div style="font-size:20px;font-weight:900;margin-top:12px">🔥 炼打卡 · 网页版</div>' +
      '<div class="muted small mt8">v1.0 · 纯本地健身打卡</div>' +
      '</div>' +
      '<div class="card">' +
      '<div class="card-title">✨ 功能一览</div>' +
      '<div style="font-size:14px;line-height:2">' +
      '📅 周一背+腰腹 · 周三胸+肩 · 周五臀+腿<br>' +
      '🧘 周六全身拉伸 · 周二四日休息<br>' +
      '🎥 器械 + 有氧教学视频<br>' +
      '📹 训练视频打卡，记录生活<br>' +
      '🤖 AI 动作审查，对比博主发力<br>' +
      '📈 渐进超负荷，自动建议加重<br>' +
      '🥗 减脂餐推荐 + 今日摄入<br>' +
      '💧 饮水打卡 · ⚖️ 身体数据趋势<br>' +
      '🏅 徽章激励 · 连续打卡<br>' +
      '</div></div>' +
      '<div class="card">' +
      '<div class="card-title">🔒 隐私说明</div>' +
      '<div class="muted small" style="line-height:1.8">所有数据仅保存在本机浏览器（localStorage + IndexedDB），不上传服务器。AI 审查时，视频截图会发送给你自己配置的大模型服务商。<br><br>插画为 AI 生成的原创蜡笔风格小男孩形象，与《蜡笔小新》官方无关，商用请自行评估版权风险。</div>' +
      '</div>'
  }
}
