// ============ 首页 ============

App.views.home = {
  async render(el) {
    const plan = getTodayPlan()
    const today = todayStr()
    const streak = getStreak()
    const wp = getWeekProgress()
    const profile = getProfile()
    const badges = calcBadges()
    const water = getWaterToday()
    const waterGoal = profile.waterGoal || 8
    const checked = isTodayChecked()

    // 本周 7 天点（一三五训练 / 六拉伸 / 二四日休息）
    const dow = weekDayOf(today)
    const mondayOffset = dow === 0 ? -6 : 1 - dow
    const checkins = get(KEY.CHECKIN, {})
    const dayCells = []
    for (let i = 0; i < 7; i++) {
      const ds = addDays(today, mondayOffset + i)
      const p = PLAN[weekDayOf(ds)]
      const done = p.type === 'rest' ? true : !!checkins[ds]
      const isToday = ds === today
      dayCells.push(
        '<div class="wd">' +
        '<div class="dot ' + (p.type === 'rest' ? 'miss' : (checkins[ds] ? 'done' : '')) + (isToday ? ' today' : '') + '">' +
        (p.type === 'rest' ? '🛌' : p.type === 'stretch' ? '🧘' : '💪') +
        '</div>' +
        '<div class="sub">' + dayName(ds).replace('周', '') + (isToday ? ' ·今' : '') + '</div>' +
        '</div>'
      )
    }

    // 今日训练卡
    let todayCard = ''
    if (plan.type === 'rest') {
      todayCard =
        '<div class="card" style="padding:0;overflow:hidden">' +
        '<img src="images/rest.jpg" style="display:block;width:100%;aspect-ratio:16/10;object-fit:cover">' +
        '<div style="padding:14px 16px 16px">' +
        '<div class="flex"><span class="pt" style="font-size:18px;font-weight:900">' + plan.emoji + ' ' + plan.title + '</span>' +
        (checked ? '<span class="tag green" style="margin-left:auto">休息 ✓</span>' : '') + '</div>' +
        '<div class="muted small mt8">' + plan.desc + '</div>' +
        '<div class="btn-row"><button class="btn blue block" onclick="App.go(\'train\')">看看本周计划</button></div>' +
        '</div></div>'
    } else {
      const exCount = (plan.exercises || []).length
      const totalSets = (plan.exercises || []).reduce((s, e) => s + e.sets, 0)
      todayCard =
        '<div class="card" style="padding:0;overflow:hidden">' +
        '<div style="background:var(--primary);padding:14px 16px;border-bottom:4px solid #2B2B2B">' +
        '<div class="flex" style="color:#fff">' +
        '<span style="font-size:20px;font-weight:900">' + plan.emoji + ' ' + plan.title + '</span>' +
        (checked ? '<span class="tag green" style="margin-left:auto">已打卡 ✓</span>' : '<span class="tag yellow" style="margin-left:auto">待打卡</span>') +
        '</div>' +
        '<div style="color:#FFE8E5;font-size:12.5px;font-weight:700;margin-top:3px">今日专注：' + plan.focus + '</div>' +
        '</div>' +
        '<div style="padding:14px 16px 16px">' +
        '<div class="flex" style="flex-wrap:wrap;gap:6px">' +
        '<span class="tag">' + exCount + ' 个动作</span>' +
        '<span class="tag">' + totalSets + ' 组</span>' +
        (plan.cardio ? '<span class="tag blue">' + esc(plan.cardio.name) + '</span>' : '') +
        '</div>' +
        (plan.cardio ? '<div class="muted small mt8">有氧：' + esc(plan.cardio.detail) + '</div>' : '') +
        '<div class="btn-row">' +
        (checked
          ? '<button class="btn green block" onclick="App.go(\'train\')">查看今天记录</button>'
          : '<button class="btn primary block" onclick="App.go(\'train-run\')">▶ 开始训练</button>') +
        '</div></div></div>'
    }

    // 存储提醒（>1GB）
    let warnBar = ''
    const usage = await getStorageUsage()
    if (usage > STORAGE_LIMIT) {
      warnBar =
        '<div class="warn-bar">⚠️<span>视频已占 <b>' + formatSize(usage) + '</b>，超过 1GB 了，去清理一下</span>' +
        '<button class="btn sm yellow" onclick="App.go(\'media\')">去清理</button></div>'
    }

    const gotBadges = badges.filter(b => b.got).length
    el.innerHTML =
      warnBar +
      '<div class="cover-card">' +
      '<img src="images/cover.jpg" alt="蜡笔小男孩举哑铃">' +
      '<div class="cover-streak"><span class="n">' + streak + '</span> <span class="label">天连续打卡 🔥</span></div>' +
      '</div>' +

      '<div class="card">' +
      '<div class="card-title">📅 本周进度 <span class="more" onclick="App.go(\'calendar\')">日历 ›</span></div>' +
      '<div class="week-dots">' + dayCells.join('') + '</div>' +
      '<div class="muted small" style="text-align:center;margin-top:8px">本周已完成 <b style="color:var(--green)">' + wp.done + '</b> / ' + wp.total + ' 次训练</div>' +
      '</div>' +

      '<div style="font-size:16px;font-weight:900;margin:2px 2px 10px">' + friendly(today) + ' · ' + dayName(today) + '</div>' +
      todayCard +

      '<div class="card">' +
      '<div class="card-title">💧 今日饮水 <span class="more">' + water + ' / ' + waterGoal + ' 杯</span></div>' +
      '<div class="water-grid" id="home-water"></div>' +
      '</div>' +

      '<div class="card">' +
      '<div class="card-title">🏅 徽章墙 <span class="more">' + gotBadges + ' / ' + badges.length + '</span></div>' +
      '<div class="badge-scroll">' +
      badges.map(b =>
        '<div class="badge-item ' + (b.got ? '' : 'locked') + '">' +
        '<div class="ic">' + b.icon + '</div><div class="nm">' + b.name + '</div></div>'
      ).join('') +
      '</div></div>' +

      '<div style="text-align:center" class="muted small">坚持就是胜利 · 休息日也在变强 💪</div>'

    // 饮水格子点击
    const grid = el.querySelector('#home-water')
    const renderCups = () => {
      const n = getWaterToday()
      let html = ''
      for (let i = 1; i <= 8; i++) {
        html += '<div class="cup ' + (i <= n ? 'full' : '') + '" data-n="' + i + '">' + (i <= n ? '💧' : '🥛') + '</div>'
      }
      grid.innerHTML = html
      grid.querySelectorAll('.cup').forEach(c => {
        c.onclick = () => {
          const n = +c.dataset.n
          const cur = getWaterToday()
          setWaterCups(cur === n ? n - 1 : n)
          renderCups()
          const t = el.querySelector('.card-title .more')
          t.textContent = getWaterToday() + ' / ' + waterGoal + ' 杯'
        }
      })
    }
    renderCups()
  }
}
