// ============ 视频库（tab）：我的视频 + 教学视频 ============

App.views.media = {
  async render(el) {
    const vids = getVideos()
    const usage = await getStorageUsage()
    const pct = Math.min(100, Math.round(usage / STORAGE_LIMIT * 100))
    const over = usage > STORAGE_LIMIT

    // 存储卡
    const storeCard =
      '<div class="card">' +
      '<div class="card-title">💾 本地存储 <span class="more" id="refresh-usage">刷新</span></div>' +
      '<div class="pbar mt8" style="margin-bottom:8px"><div class="fill ' + (pct >= 100 ? 'full' : '') + '" style="width:' + pct + '%;' + (over ? 'background:#E23B2E' : '') + '"></div>' +
      '<div class="ptext">' + formatSize(usage) + ' / 1GB</div></div>' +
      '<div class="muted small">视频保存在这台设备的浏览器里，不会上传云端。建议重要的视频「⬇️ 下载」备份</div>' +
      '<div class="btn-row">' +
      '<button class="btn primary" id="add-video">📷 记录新视频</button>' +
      '<button class="btn yellow" id="clean-video">🧹 清理30天前</button>' +
      '</div></div>'

    // 我的视频列表
    let listHtml = ''
    if (!vids.length) {
      listHtml = '<div class="empty"><span class="e-ic">🎬</span>还没有训练视频<br>训练结束时或点上方按钮，拍一段记录生活吧</div>'
    } else {
      listHtml = await Promise.all(vids.map(async v => {
        const rep = getReview(v.id)
        return (
          '<div class="video-card" data-vid="' + v.id + '">' +
          '<div class="vc-load" style="background:#2B2B2B;min-height:120px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:900">加载中…</div>' +
          '<div class="vc-bar">' +
          '<div class="vc-main">' +
          '<div class="vc-title">' + (v.starred ? '⭐ ' : '') + esc(v.name) + '</div>' +
          '<div class="vc-sub">' + v.date + ' · ' + formatSize(v.size) +
          (rep ? ' · AI评分 <b style="color:var(--primary)">' + rep.score + '</b>' : '') + '</div>' +
          '</div>' +
          '<div class="vc-acts">' +
          '<button class="star-btn ' + (v.starred ? 'on' : '') + '" data-act="star">' + (v.starred ? '⭐' : '☆') + '</button>' +
          '<button class="btn sm blue" data-act="review">🤖 AI</button>' +
          '<button class="btn sm green" data-act="download">⬇️</button>' +
          '<button class="btn sm" data-act="del" style="border-color:#E23B2E;color:#E23B2E">🗑</button>' +
          '</div>' +
          '</div></div>'
        )
      })).then(cards => cards.join(''))
    }

    // 教学视频库
    const cats = ['器械教学', '有氧入门', '练后拉伸', '休息日放松']
    const teachHtml = cats.map(cat => {
      const items = VIDEO_LIB.filter(v => v.cat === cat)
      return (
        '<div class="card"><div class="card-title">🎥 ' + cat + '</div>' +
        items.map(v => {
          const m = v.title.match(/^(.+?) ·/)
          const exName = m ? m[1] : ''
          const ex = getAllExercises().find(e => e.name === exName)
          const jump = ex ? ' onclick="App.go(\'exercise?id=' + ex.id + '\')"' : ''
          return (
            '<div class="row-item" style="cursor:pointer" onclick="App.views.media.playTeach(\'' + v.id + '\')">' +
            '<div class="ri-ic">🎞️</div>' +
            '<div class="ri-main"><div class="ri-title">' + esc(v.title) + '</div>' +
            '<div class="ri-sub">' + esc(v.note) + ' · 时长 ' + v.dur + '</div></div>' +
            '<div class="ri-right"><div class="b1">▶</div></div>' +
            '</div>'
          )
        }).join('') + '</div>'
      )
    }).join('')

    el.innerHTML = storeCard +
      '<div style="font-size:16px;font-weight:900;margin:2px 2px 10px">📹 我的视频（' + vids.length + '）</div>' +
      listHtml +
      '<div style="font-size:16px;font-weight:900;margin:18px 2px 10px">📚 教学视频库</div>' +
      teachHtml

    // ---------- 交互 ----------
    el.querySelector('#add-video').onclick = async () => {
      const f = await App.pickVideo()
      if (!f) return
      if (f.size > 200 * 1024 * 1024) { App.toast('单个视频超过 200MB，存不下'); return }
      App.modal({ title: '⏳ 保存中', body: '<div class="loading-dots"><i></i><i></i><i></i></div>', noClose: true })
      try {
        await App.saveVideoFile(f, {
          name: (getTodayPlan().title || '训练') + ' · ' + friendly(todayStr()),
          date: todayStr(),
          type: 'checkin'
        })
        App.closeModal()
        App.toast('已保存 ✓')
        App.route()
      } catch (e) {
        App.closeModal()
        App.modal({ title: '❌ 保存失败', body: '浏览器存储空间不足或权限受限', buttons: [{ text: '知道了', cls: 'primary' }] })
      }
    }

    el.querySelector('#clean-video').onclick = () => {
      const olds = getVideos().filter(v => v.date < addDays(todayStr(), -30) && !v.starred)
      if (!olds.length) { App.toast('没有可清理的旧视频'); return }
      App.modal({
        title: '🧹 一键清理',
        body: '将删除 <b>' + olds.length + '</b> 条 30 天前且未星标的视频（约 ' + formatSize(olds.reduce((s, v) => s + v.size, 0)) + '），星标的会保留',
        buttons: [
          { text: '取消' },
          {
            text: '删除', cls: 'primary', cb: async () => {
              await cleanOldVideos(30)
              App.toast('清理完成 ✓')
              App.route()
            }
          }
        ]
      })
    }

    el.querySelector('#refresh-usage').onclick = () => App.route()

    // 视频卡片：懒加载 blob
    el.querySelectorAll('.video-card').forEach(card => {
      const id = card.dataset.vid
      VDB.get(id).then(blob => {
        const slot = card.querySelector('.vc-load')
        if (!blob) { slot.textContent = '文件丢失（可能被浏览器清理）'; slot.style.minHeight = '60px'; return }
        const video = document.createElement('video')
        video.controls = true
        video.playsInline = true
        video.preload = 'metadata'
        video.src = URL.createObjectURL(blob)
        video.style.cssText = 'display:block;width:100%;max-height:300px;background:#2B2B2B'
        slot.replaceWith(video)
      })

      card.querySelectorAll('[data-act]').forEach(btn => {
        btn.onclick = async (e) => {
          e.stopPropagation()
          const act = btn.dataset.act
          const meta = getVideos().find(v => v.id === id)
          if (act === 'star') {
            toggleVideoStar(id)
            App.route()
          } else if (act === 'review') {
            App.go('review?vid=' + id)
          } else if (act === 'download') {
            await App.downloadVideo(id, meta ? meta.name : 'training')
          } else if (act === 'del') {
            App.modal({
              title: '删除视频？',
              body: '「' + esc(meta ? meta.name : '') + '」删除后无法恢复，建议先下载备份',
              buttons: [
                { text: '取消' },
                {
                  text: '删除', cls: 'primary', cb: async () => {
                    await deleteVideo(id)
                    App.toast('已删除')
                    App.route()
                  }
                }
              ]
            })
          }
        }
      })
    })
  },

  playTeach(vid) {
    const v = VIDEO_LIB.find(x => x.id === vid)
    if (!v) return
    App.modal({
      title: '▶ ' + esc(v.title),
      body: '<video src="' + v.url + '" controls playsinline style="width:100%;border-radius:14px;border:3px solid #2B2B2B;background:#2B2B2B"></video>' +
        '<div class="muted small" style="margin-top:8px">' + esc(v.note) + ' · ' + v.dur + '</div>',
      buttons: [{ text: '关闭', cls: 'primary' }]
    })
  }
}
