// ============ 减脂饮食页 ============

App.views.diet = {
  render(el) {
    const profile = getProfile()
    const targetKcal = profile.targetKcal || 1800
    const targetPro = profile.targetProtein || 120

    const logs = getDietToday()
    const sumKcal = logs.reduce((s, l) => s + (l.kcal || 0), 0)
    const sumPro = logs.reduce((s, l) => s + (l.protein || 0), 0)
    const kcalPct = Math.min(100, Math.round(sumKcal / targetKcal * 100))
    const proPct = Math.min(100, Math.round(sumPro / targetPro * 100))

    const mealDefs = [
      { key: 'breakfast', name: '早餐', icon: '🌅' },
      { key: 'lunch', name: '午餐', icon: '☀️' },
      { key: 'dinner', name: '晚餐', icon: '🌙' },
      { key: 'snack', name: '加餐', icon: '🍎' }
    ]

    const mealCards = mealDefs.map(m => {
      const items = MEALS[m.key] || []
      return (
        '<div class="meal-card">' +
        '<div class="mc-head">' + m.icon + ' ' + m.name +
        '<span class="mc-tag tag yellow">' + items.length + ' 个推荐</span></div>' +
        items.map(item =>
          '<div class="meal-item" data-meal="' + item.id + '">' +
          '<div class="mi-main">' +
          '<div class="mi-name">' + esc(item.name) + '</div>' +
          '<div class="mi-detail">' + esc(item.detail) + '</div>' +
          '</div>' +
          '<div class="mi-kcal"><div class="k1">' + item.kcal + ' <span style="font-size:11px">kcal</span></div>' +
          '<div class="k2">蛋白 ' + item.protein + 'g</div></div>' +
          '<button class="btn sm green" data-add>＋</button>' +
          '</div>'
        ).join('') +
        '</div>'
      )
    }).join('')

    const logHtml = logs.length
      ? logs.map((l, i) =>
        '<div class="row-item">' +
        '<div class="ri-ic">🍽️</div>' +
        '<div class="ri-main"><div class="ri-title">' + esc(l.name) + '</div>' +
        '<div class="ri-sub">' + l.mealName + ' · ' + l.kcal + 'kcal · 蛋白' + l.protein + 'g</div></div>' +
        '<button class="btn sm" data-del="' + i + '" style="border-color:#E23B2E;color:#E23B2E">－</button>' +
        '</div>'
      ).join('')
      : '<div class="muted small" style="text-align:center;padding:12px 0">今天还没记录，从上面推荐里点 ＋ 添加</div>'

    el.innerHTML =
      '<div class="card">' +
      '<div class="card-title">📊 今日摄入 <span class="more" onclick="App.go(\'settings\')">改目标</span></div>' +
      '<div style="margin-bottom:12px"><div class="muted small" style="margin-bottom:5px">热量 ' + sumKcal + ' / ' + targetKcal + ' kcal</div>' +
      '<div class="pbar"><div class="fill ' + (kcalPct >= 100 ? 'full' : '') + '" style="width:' + kcalPct + '%"></div><div class="ptext">' + kcalPct + '%</div></div></div>' +
      '<div><div class="muted small" style="margin-bottom:5px">蛋白质 ' + sumPro + ' / ' + targetPro + ' g</div>' +
      '<div class="pbar"><div class="fill ' + (proPct >= 100 ? 'full' : '') + '" style="width:' + proPct + '%;background:var(--blue)"></div><div class="ptext">' + proPct + '%</div></div></div>' +
      '</div>' +

      '<div class="card"><div class="card-title">📝 今日已吃（' + logs.length + '）</div>' + logHtml + '</div>' +
      mealCards +
      '<div class="muted small" style="text-align:center">餐单参考健身博主的经典减脂搭配 · 可在设置里调整热量目标</div>'

    // 添加
    el.querySelectorAll('.meal-item').forEach(item => {
      const addBtn = item.querySelector('[data-add]')
      addBtn.onclick = () => {
        const id = item.dataset.meal
        let found = null, mealName = ''
        for (const m of mealDefs) {
          found = (MEALS[m.key] || []).find(x => x.id === id)
          if (found) { mealName = m.name; break }
        }
        if (!found) return
        addDietLog({
          mealId: found.id, mealName,
          name: found.name, kcal: found.kcal, protein: found.protein
        })
        App.toast('已记录「' + found.name + '」')
        App.route()
      }
    })
    // 删除
    el.querySelectorAll('[data-del]').forEach(b => {
      b.onclick = () => {
        removeDietLog(+b.dataset.del)
        App.toast('已删除')
        App.route()
      }
    })
  }
}
