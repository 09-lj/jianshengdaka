// ============ AI 动作审查页 ============

App.views.review = {
  render(el, params) {
    const allEx = getAllExercises()
    const profile = getProfile()
    const cfg = getAiConfig()
    const exId = params.ex || allEx[0].id
    const vids = getVideos()

    el.innerHTML =
      (!cfg.apiKey
        ? '<div class="warn-bar">🤖<span>还没有配置 AI：到「设置 → AI 动作审查」填一个 API Key</span>' +
        '<button class="btn sm yellow" onclick="App.go(\'settings\')">去配置</button></div>'
        : '') +

      '<div class="card">' +
      '<div class="card-title">🏋️ 选择审查的动作</div>' +
      '<div class="chip-row" id="ex-chips">' +
      allEx.map(ex =>
        '<div class="chip ' + (ex.id === exId ? 'active' : '') + '" data-ex="' + ex.id + '">' + esc(ex.name) + '</div>'
      ).join('') +
      '</div></div>' +

      '<div class="card">' +
      '<div class="card-title">📷 训练视频</div>' +
      '<div class="btn-row" style="margin-top:0">' +
      '<button class="btn primary block" id="pick-new">拍一段 / 选文件</button>' +
      '</div>' +
      (vids.length
        ? '<div class="muted small mt12" style="text-align:center">或者从视频库选：</div>' +
        '<div class="mt8" id="pick-old">' +
        vids.slice(0, 6).map(v =>
          '<div class="row-item" data-vid="' + v.id + '" style="cursor:pointer">' +
          '<div class="ri-ic">🎞️</div>' +
          '<div class="ri-main"><div class="ri-title">' + esc(v.name) + '</div>' +
          '<div class="ri-sub">' + v.date + ' · ' + formatSize(v.size) + '</div></div>' +
          '<div class="ri-right"><div class="b1">用这条</div></div></div>'
        ).join('') + '</div>'
        : '') +
      '</div>' +

      '<div class="card" id="stage-card" style="display:none">' +
      '<div class="card-title" id="stage-title"></div>' +
      '<div class="frame-strip" id="frames"></div>' +
      '<div class="muted small" id="stage-text"></div>' +
      '</div>' +

      '<div id="report"></div>'

    // 动作选择
    el.querySelectorAll('#ex-chips .chip').forEach(c => {
      c.onclick = () => {
        el.querySelectorAll('#ex-chips .chip').forEach(x => x.classList.remove('active'))
        c.classList.add('active')
      }
    })

    const getSelectedEx = () => {
      const active = el.querySelector('#ex-chips .chip.active')
      return allEx.find(e => e.id === (active ? active.dataset.ex : exId)) || allEx[0]
    }

    // 新视频
    el.querySelector('#pick-new').onclick = async () => {
      const f = await App.pickVideo()
      if (!f) return
      if (f.size > 150 * 1024 * 1024) { App.toast('视频太大（>150MB），换个短一点的'); return }
      this.analyze(el, getSelectedEx(), f)
    }
    // 视频库选择
    el.querySelectorAll('#pick-old .row-item').forEach(r => {
      r.onclick = async () => {
        const blob = await VDB.get(r.dataset.vid)
        if (!blob) { App.toast('视频文件读取失败'); return }
        this.analyze(el, getSelectedEx(), blob, r.dataset.vid)
      }
    })
  },

  async analyze(el, ex, blob, vid) {
    const gender = getProfile().gender || 'male'
    const stage = el.querySelector('#stage-card')
    const reportBox = el.querySelector('#report')
    stage.style.display = 'block'
    reportBox.innerHTML = ''
    el.querySelector('#stage-title').innerHTML = '🔍 抓取关键帧 <span class="loading-dots"><i></i><i></i><i></i></span>'
    el.querySelector('#stage-text').textContent = esc(ex.name) + ' · 正在从视频中抽取 4 个关键画面…'
    el.querySelector('#frames').innerHTML = ''
    stage.scrollIntoView({ behavior: 'smooth', block: 'start' })

    // 1. 抓帧
    let frames
    try {
      frames = await grabFrames(blob, 4)
    } catch (e) {
      stage.style.display = 'none'
      App.modal({ title: '😅 抓帧失败', body: esc(e.message || '视频无法解析'), buttons: [{ text: '知道了', cls: 'primary' }] })
      return
    }
    el.querySelector('#frames').innerHTML = frames.map(b64 =>
      '<img src="data:image/jpeg;base64,' + b64 + '">'
    ).join('')
    el.querySelector('#stage-title').textContent = '🤖 AI 分析中'

    // 2. 调模型
    try {
      el.querySelector('#stage-text').innerHTML =
        'AI 教练正在对比<b>博主发力标准</b>逐帧审查，约需 10-30 秒…<span class="loading-dots"><i></i><i></i><i></i></span>'
      const report = await review(ex, frames, gender)

      // 保存报告
      if (vid) saveReview(vid, report, { id: ex.id, name: ex.name })
      el.querySelector('#stage-text').textContent = '分析完成，报告如下 👇'
      this.renderReport(reportBox, report)
    } catch (e) {
      el.querySelector('#stage-title').textContent = '❌ 分析失败'
      el.querySelector('#stage-text').textContent = ''
      App.modal({
        title: '❌ AI 分析失败',
        body: esc(e && e.msg ? e.msg : '未知错误') +
          (e && e.code === 'NO_KEY' ? '<br><br>到「设置 → AI 动作审查」配置后重试' : ''),
        buttons: [{ text: '知道了', cls: 'primary' }]
      })
    }
  },

  renderReport(box, r) {
    const pct = Math.max(0, Math.min(100, r.score))
    const matchPct = Math.max(0, Math.min(100, r.match))
    const ringColor = pct >= 80 ? '#7CB342' : pct >= 60 ? '#F5A623' : '#E23B2E'
    const levelCls = r.level === '优秀' ? 'green' : r.level === '良好' ? 'blue' : r.level === '合格' ? 'yellow' : 'red'

    box.innerHTML =
      '<div class="card">' +
      '<div class="flex" style="align-items:flex-start">' +
      '<div class="score-ring" style="--pct:' + pct + ';--rc:' + ringColor + '">' +
      '<div class="sc"><div class="n">' + r.score + '</div><div class="lb">动作评分</div></div>' +
      '</div>' +
      '<div style="flex:1;min-width:0;padding-left:14px">' +
      '<div class="flex"><span class="tag ' + levelCls + '">' + esc(r.level) + '</span>' +
      '<span class="tag">🤝 相似度 ' + matchPct + '%</span></div>' +
      '<div style="font-weight:900;font-size:15px;line-height:1.6;margin-top:10px">' + esc(r.summary) + '</div>' +
      '</div></div></div>' +

      (r.diffs && r.diffs.length
        ? '<div class="card"><div class="card-title">🔍 对比博主的发力差异</div>' +
        r.diffs.map(d =>
          '<div class="diff-box sug"><div class="dt">🧭 ' + esc(d.point || '') + '</div><div class="dd">' + esc(d.detail || '') + '</div></div>'
        ).join('') + '</div>'
        : '') +

      (r.issues && r.issues.length
        ? '<div class="card"><div class="card-title">⚠️ 问题点</div>' +
        r.issues.map(i =>
          '<div class="diff-box sev-' + (i.severity || '中') + '"><div class="dt">' +
          '<span class="tag ' + (i.severity === '高' ? 'red' : i.severity === '中' ? 'yellow' : 'green') + '" style="font-size:11px;padding:1px 8px">' + esc(i.severity || '中') + '</span>' +
          esc(i.title || '') + '</div><div class="dd">' + esc(i.detail || '') + '</div></div>'
        ).join('') + '</div>'
        : '') +

      (r.suggestions && r.suggestions.length
        ? '<div class="card"><div class="card-title">🎯 下次这样改进</div>' +
        r.suggestions.map((s, i) =>
          '<div class="diff-box" style="background:#E8F4DD"><div class="dt">' + (i + 1) + '. ' + esc(s.title || '') + '</div><div class="dd">' + esc(s.detail || '') + '</div></div>'
        ).join('') + '</div>'
        : '') +

      '<div class="muted small" style="text-align:center;margin-top:4px">AI 审查仅供参考，以自身感受和教练现场指导为准</div>'
  }
}
