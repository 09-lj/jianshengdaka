// ============ 视频文件库（IndexedDB 存 blob，元数据在 localStorage） ============
// 网页 localStorage 只有 ~5MB，存不下视频；视频本体放 IndexedDB（浏览器配额一般有几 GB）

const VDB = {
  _db: null,

  open() {
    if (this._db) return Promise.resolve(this._db)
    return new Promise((resolve, reject) => {
      const req = indexedDB.open('fitness-videos', 1)
      req.onupgradeneeded = () => {
        const db = req.result
        if (!db.objectStoreNames.contains('videos')) db.createObjectStore('videos')
      }
      req.onsuccess = () => { this._db = req.result; resolve(req.result) }
      req.onerror = () => reject(req.error)
    })
  },

  async put(id, blob) {
    const db = await this.open()
    return new Promise((resolve, reject) => {
      const tx = db.transaction('videos', 'readwrite')
      tx.objectStore('videos').put(blob, id)
      tx.oncomplete = () => resolve(true)
      tx.onerror = () => reject(tx.error)
    })
  },

  async get(id) {
    const db = await this.open()
    return new Promise((resolve) => {
      const tx = db.transaction('videos', 'readonly')
      const req = tx.objectStore('videos').get(id)
      req.onsuccess = () => resolve(req.result || null)
      req.onerror = () => resolve(null)
    })
  },

  async del(id) {
    const db = await this.open()
    return new Promise((resolve) => {
      const tx = db.transaction('videos', 'readwrite')
      tx.objectStore('videos').delete(id)
      tx.oncomplete = () => resolve(true)
      tx.onerror = () => resolve(false)
    })
  },

  async clear() {
    const db = await this.open()
    return new Promise((resolve) => {
      const tx = db.transaction('videos', 'readwrite')
      tx.objectStore('videos').clear()
      tx.oncomplete = () => resolve(true)
      tx.onerror = () => resolve(false)
    })
  }
}
