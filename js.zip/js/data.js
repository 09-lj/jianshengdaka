// ============ 炼打卡 · 网页版 - 种子数据 ============
// 动作库 / 教学视频库 / 减脂餐单 / 徽章定义
// 数组下标 = new Date().getDay()，0 = 周日

const PLAN = [
  {
    day: 0, type: 'rest', title: '完全休息', emoji: '🛌',
    desc: '今天不练，好好吃饭好好睡觉，肌肉在悄悄生长',
    exercises: []
  },
  {
    day: 1, type: 'train', title: '背 + 腰腹', emoji: '💪',
    focus: '背阔肌 · 核心稳定',
    cardio: { name: '跑步机坡度快走', detail: '坡度 8% · 速度 5.5km/h · 20 分钟' },
    exercises: [
      {
        id: 'pulldown', name: '高位下拉', sets: 4, reps: 12, unit: 'kg',
        male: [20, 30], female: [10, 20],
        tips: '先沉肩再下拉，想象肘部贴着身体两侧把杆拉到锁骨位置，最低点挤压背阔肌 1 秒再慢放',
        errors: '身体过度后仰借力；重量太大导致耸肩，斜方肌代偿',
        muscle: '背阔肌、大圆肌、肱二头肌辅助',
        stdMind: '启动时先下沉肩胛骨再拉杆，肘部沿身体两侧向下向后走，最低点主动挤压背阔肌 1 秒；离心阶段用背部控制杆缓慢回位，不靠手臂抢戏。',
        stdTempo: '上拉 1 秒 · 顶峰停顿 1 秒 · 回放 2 秒',
        devi: '身体后仰借力、耸肩、用手臂先发力、回放时直接放开让重量自由落体'
      },
      {
        id: 'row', name: '坐姿划船', sets: 4, reps: 12, unit: 'kg',
        male: [20, 30], female: [15, 25],
        tips: '背部挺直，把手拉向腹部，肘部贴身，感受两侧肩胛骨向中间收紧',
        errors: '弓背发力；靠身体前后晃动"甩"起重量',
        muscle: '中背、菱形肌、背阔肌',
        stdMind: '躯干全程稳定不晃动，肘部贴近身体向后拉，顶点时两侧肩胛骨往脊柱中间夹紧，感受背部中间收缩而不是手臂酸。',
        stdTempo: '拉 1 秒 · 夹紧 1 秒 · 慢放 2 秒',
        devi: '来回晃动身体甩重量、圆背发力、肘部外展过大变成练后束'
      },
      {
        id: 'pushdown', name: '直臂下压', sets: 3, reps: 15, unit: 'kg',
        male: [15, 25], female: [10, 20],
        tips: '手臂保持伸直，只靠肩关节转动把杆压到大腿前侧，是大圆肌和背阔肌的专属动作',
        errors: '肘部弯曲变成练三头，背部刺激消失',
        muscle: '背阔肌、大圆肌',
        stdMind: '手肘微屈并固定角度不变，靠肩关节向下转动把手压到大腿前，全程手臂像一根杠杆。',
        stdTempo: '下压 1 秒 · 底部停 0.5 秒 · 回放 2 秒',
        devi: '手肘弯曲变成练三头、耸肩、用躯干下压'
      },
      {
        id: 'crunch', name: '卷腹', sets: 3, reps: 20, unit: '次',
        male: null, female: null,
        tips: '下背贴地，用腹肌把肩胛骨卷离地面，起身呼气、下放吸气',
        errors: '双手抱头猛拉颈椎；靠惯性甩起来',
        muscle: '腹直肌',
        stdMind: '下背始终贴地，用腹肌把肩胛骨卷离地面，呼气起身、吸气下放，动作幅度小而准。',
        stdTempo: '卷起 1 秒 · 顶峰停 0.5 秒 · 下放 2 秒',
        devi: '双手抱头拉扯颈椎、靠惯性甩、起身过高变成练髋屈肌'
      },
      {
        id: 'plank', name: '平板支撑', sets: 3, reps: 45, unit: '秒',
        male: null, female: null,
        tips: '肘部在肩正下方，核心收紧，从头到脚一条直线，自然呼吸不憋气',
        errors: '塌腰或撅臀；坚持不住时宁可提前结束也别变形',
        muscle: '腹横肌、核心整体',
        stdMind: '肘部在肩正下方，臀部和腹部同时收紧，从头到脚保持一条直线，全程自然呼吸。',
        stdTempo: '静态保持，均匀呼吸不憋气',
        devi: '塌腰、撅臀、耸肩、憋气'
      }
    ]
  },
  {
    day: 2, type: 'rest', title: '休息日', emoji: '🌿',
    desc: '肌肉是在休息中生长的。今天可以散散步、早点睡',
    exercises: []
  },
  {
    day: 3, type: 'train', title: '胸 + 肩', emoji: '🔥',
    focus: '胸大肌 · 三角肌',
    cardio: { name: '椭圆机', detail: '中等阻力 · 20 分钟 · 心率控制在 120-140' },
    exercises: [
      {
        id: 'smith-bench', name: '史密斯卧推', sets: 4, reps: 12, unit: 'kg',
        male: [20, 30], female: [10, 20],
        tips: '肩胛骨后收下沉贴稳凳面，杠落到乳头连线附近，推起时不必完全锁死手肘',
        errors: '手肘外展接近 90° 肩部压力大；腰部起桥过高用腿借力',
        muscle: '胸大肌、三角肌前束、肱三头肌',
        stdMind: '肩胛骨后收下沉紧贴凳面，杠铃下落到乳头连线附近，推起时胸部主动发力，手肘保持约 45 度夹角。',
        stdTempo: '下放 2 秒 · 底部停 0.5 秒 · 推起 1 秒',
        devi: '手肘外展接近 90 度压迫肩关节、腰部起桥过高、靠腿部借力'
      },
      {
        id: 'chest-press', name: '坐姿推胸', sets: 4, reps: 12, unit: 'kg',
        male: [25, 40], female: [15, 25],
        tips: '背和头贴稳靠垫，把手沿弧线推向胸前正前方，下放到大臂略过身体平面',
        errors: '耸肩；推的过程中肩膀离开靠垫',
        muscle: '胸大肌',
        stdMind: '背和头贴稳靠垫，把手沿弧线推向胸前正前方，推到位时胸部挤压，回位时控制住不要让配重砸回去。',
        stdTempo: '推 1 秒 · 顶停 0.5 秒 · 回 2 秒',
        devi: '耸肩、肩膀离开靠垫、回位时自由落体'
      },
      {
        id: 'db-shoulder', name: '哑铃肩推', sets: 4, reps: 12, unit: 'kg/只',
        male: [7.5, 12.5], female: [2.5, 5],
        tips: '坐带靠背的凳，哑铃从耳侧推过头顶，全程控制不碰撞',
        errors: '腰部过度反弓；只做半程行程',
        muscle: '三角肌前中束',
        stdMind: '坐稳靠背，核心收紧避免腰部反弓，哑铃从耳侧向上推至头顶上方，全程控制不碰撞。',
        stdTempo: '推起 1 秒 · 顶停 0.5 秒 · 下放 2 秒',
        devi: '腰部过度反弓、只做半程、下放过低伤肩'
      },
      {
        id: 'lateral-raise', name: '侧平举', sets: 3, reps: 15, unit: 'kg',
        male: [5, 7.5], female: [2, 4],
        tips: '肘部微屈固定角度，抬到与肩同高即可，想象"用肘部带小臂"',
        errors: '甩动借力；抬得过高超过肩线，斜方肌接管',
        muscle: '三角肌中束',
        stdMind: '手肘微屈固定角度，想象用肘部带动小臂向两侧抬起，抬到与肩同高即可，肩部始终下沉。',
        stdTempo: '抬起 1 秒 · 顶停 0.5 秒 · 下放 2 秒',
        devi: '甩动借力、抬过肩线导致斜方肌接管、耸肩'
      }
    ]
  },
  {
    day: 4, type: 'rest', title: '休息日', emoji: '🌿',
    desc: '休息也是训练计划的一部分，别有负罪感',
    exercises: []
  },
  {
    day: 5, type: 'train', title: '臀 + 腿', emoji: '🦵',
    focus: '臀大肌 · 股四头肌 · 腘绳肌',
    cardio: { name: '动感单车', detail: '中等阻力 · 20 分钟 · 保持踏频稳定' },
    exercises: [
      {
        id: 'leg-press', name: '腿举', sets: 4, reps: 12, unit: 'kg',
        male: [40, 60], female: [30, 50],
        tips: '双脚与肩同宽踩在踏板中上部，下放大腿至约 90° 即可，全程腰背贴稳靠垫',
        errors: '下放过深导致腰部离开垫面；膝盖内扣',
        muscle: '股四头肌、臀大肌',
        stdMind: '双脚与肩同宽踩在踏板中上部，腰背和臀部全程贴紧靠垫，下放到大腿约 90 度即可推起，膝盖方向对准脚尖。',
        stdTempo: '下放 2 秒 · 底部停 0.5 秒 · 蹬起 1 秒',
        devi: '下放过深导致腰部离开垫面、膝盖内扣、锁死膝关节'
      },
      {
        id: 'hip-thrust', name: '臀推', sets: 4, reps: 12, unit: 'kg',
        male: [20, 40], female: [10, 20],
        tips: '肩胛骨下沿靠住凳边，用臀部发力把髋顶到躯干与地面平行，顶点停 1 秒',
        errors: '用腰过度伸展代偿；下巴朝天发力',
        muscle: '臀大肌、腘绳肌',
        stdMind: '肩胛骨下沿靠住凳边，下巴微收看前方，用臀部发力把髋顶到躯干与地面平行，顶点主动夹紧臀部 1 秒。',
        stdTempo: '顶起 1 秒 · 顶峰夹紧 1 秒 · 下放 2 秒',
        devi: '用腰部过度伸展代偿、下巴朝天、顶点不停顿'
      },
      {
        id: 'leg-curl', name: '腿弯举', sets: 3, reps: 15, unit: 'kg',
        male: [20, 30], female: [10, 20],
        tips: '大腿贴稳垫面，匀速弯起、慢速放下，感受大腿后侧发力',
        errors: '臀部抬起来借力；放的过程自由落体',
        muscle: '腘绳肌（大腿后侧）',
        stdMind: '大腿贴稳垫面，用大腿后侧发力匀速弯起，回放时慢慢控制，不在最高点用惯性甩下。',
        stdTempo: '弯起 1 秒 · 顶停 0.5 秒 · 回放 2 秒',
        devi: '臀部抬起借力、回放自由落体、幅度不完全'
      },
      {
        id: 'db-lunge', name: '哑铃箭步蹲', sets: 3, reps: 12, unit: 'kg/只',
        male: [7.5, 12.5], female: [2.5, 5],
        tips: '迈步距离适中，身体垂直下降，前侧膝盖方向对准脚尖',
        errors: '上身前倾；后腿膝盖砸向地面',
        muscle: '臀大肌、股四头肌',
        stdMind: '迈步距离适中，躯干保持垂直下降，前侧膝盖方向对准脚尖且不超过脚尖太多，后侧膝盖轻接近地面。',
        stdTempo: '下蹲 2 秒 · 底部停 0.5 秒 · 站起 1 秒',
        devi: '上身前倾、后腿膝盖砸地、前膝内扣'
      }
    ]
  },
  {
    day: 6, type: 'stretch', title: '全身拉伸', emoji: '🧘',
    focus: '主动恢复 · 泡沫轴放松',
    cardio: null,
    exercises: [
      {
        id: 'foam-back', name: '泡沫轴 · 上背滚动', sets: 2, reps: 60, unit: '秒',
        male: null, female: null,
        tips: '双手抱头护住颈椎，泡沫轴放在肩胛骨位置来回缓滚，呼气时加重一点',
        errors: '滚到腰椎（腰要靠地面稳定，不滚腰）',
        muscle: '胸椎、上背筋膜',
        stdMind: '双手抱头护住颈椎，泡沫轴置于肩胛骨区域缓慢来回滚动，遇到酸点停留并深呼吸放松。',
        stdTempo: '缓慢滚动，每秒不超过 5 厘米',
        devi: '滚到腰椎（腰椎需贴地稳定）、滚得太快'
      },
      {
        id: 'foam-leg', name: '泡沫轴 · 大腿前后侧', sets: 2, reps: 60, unit: '秒/侧',
        male: null, female: null,
        tips: '前侧从髋滚到膝上方，后侧从臀下滚到膝后，遇到酸点停留深呼吸 3 次',
        errors: '滚得越快越好（应该慢，酸点停留）',
        muscle: '股四头肌、腘绳肌、髂胫束',
        stdMind: '前侧从髋滚到膝上方，后侧从臀下滚到膝后，遇到酸点停留深呼吸 3 次再继续。',
        stdTempo: '缓慢滚动，酸点停留 5-10 秒',
        devi: '滚得过快、直接压在膝关节上'
      },
      {
        id: 'cat-cow', name: '猫牛式', sets: 2, reps: 10, unit: '次',
        male: null, female: null,
        tips: '四点跪姿，吸气抬头塌腰，呼气低头拱背，跟随呼吸节奏',
        errors: '动作过快，没有配合呼吸',
        muscle: '脊柱灵活性、核心',
        stdMind: '四点跪姿，吸气时抬头塌腰、呼气时低头拱背，让每一节脊椎依次活动，跟随呼吸节奏。',
        stdTempo: '配合呼吸，一吸一呼为一组',
        devi: '动作过快、只动腰不动胸椎、憋气'
      },
      {
        id: 'forward-fold', name: '站姿体前屈', sets: 2, reps: 30, unit: '秒',
        male: null, female: null,
        tips: '膝盖微弯，让头部自然下垂放松整个背部，感受大腿后侧的牵拉',
        errors: '锁死膝盖硬压；憋气',
        muscle: '腘绳肌、下背',
        stdMind: '膝盖微屈不锁死，让头部自然下垂放松整个背部，感受大腿后侧的牵拉而不是腰部被压。',
        stdTempo: '静态保持 30 秒，自然呼吸',
        devi: '锁死膝盖硬压、憋气、弹震式下压'
      }
    ]
  }
]

// ---------- 教学视频库（公开 CC0 演示源，可换成自己的教学视频） ----------
const DEMO_URLS = [
  'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4',
  'https://www.w3schools.com/html/mov_bbb.mp4',
  'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/friday.mp4'
]

const VIDEO_LIB = [
  { id: 't-pulldown', cat: '器械教学', title: '高位下拉 · 标准动作示范', dur: '03:42', url: DEMO_URLS[0], note: '周一 · 背' },
  { id: 't-row', cat: '器械教学', title: '坐姿划船 · 发力细节讲解', dur: '04:15', url: DEMO_URLS[1], note: '周一 · 背' },
  { id: 't-bench', cat: '器械教学', title: '史密斯卧推 · 新手安全指南', dur: '05:08', url: DEMO_URLS[2], note: '周三 · 胸' },
  { id: 't-press', cat: '器械教学', title: '腿举 · 常见错误纠正', dur: '04:30', url: DEMO_URLS[0], note: '周五 · 腿' },
  { id: 'c-walk', cat: '有氧入门', title: '跑步机坡度快走 · 正确姿势', dur: '02:50', url: DEMO_URLS[1], note: '减脂主力' },
  { id: 'c-elliptical', cat: '有氧入门', title: '椭圆机 20 分钟入门课程', dur: '06:20', url: DEMO_URLS[2], note: '护膝首选' },
  { id: 'c-bike', cat: '有氧入门', title: '动感单车 · 阻力与踏频', dur: '03:36', url: DEMO_URLS[0], note: '周五 · 有氧' },
  { id: 's-back', cat: '练后拉伸', title: '背部放松 · 5 分钟跟练', dur: '05:00', url: DEMO_URLS[1], note: '周一练后' },
  { id: 's-chest', cat: '练后拉伸', title: '肩胸打开 · 5 分钟跟练', dur: '05:00', url: DEMO_URLS[2], note: '周三练后' },
  { id: 's-leg', cat: '练后拉伸', title: '下肢拉伸 · 6 分钟跟练', dur: '06:12', url: DEMO_URLS[0], note: '周五练后' },
  { id: 'r-foam', cat: '休息日放松', title: '泡沫轴全身放松 · 完整版', dur: '12:00', url: DEMO_URLS[1], note: '周六' },
  { id: 'r-yoga', cat: '休息日放松', title: '睡前舒缓瑜伽 · 助眠', dur: '15:00', url: DEMO_URLS[2], note: '周日也OK' },
  { id: 'r-hip', cat: '休息日放松', title: '髋部灵活性 · 久坐人群必练', dur: '10:00', url: DEMO_URLS[0], note: '随时随地' }
]

const MEALS = {
  breakfast: [
    { id: 'b1', name: '燕麦鸡蛋能量碗', detail: '燕麦 50g + 牛奶 250ml + 鸡蛋 2 个 + 蓝莓一小把', kcal: 420, protein: 28, from: '博主经典早餐' },
    { id: 'b2', name: '全麦鸡蛋三明治', detail: '全麦吐司 2 片 + 煎蛋 + 生菜 + 番茄 + 无糖酸奶', kcal: 450, protein: 25, from: '快手 5 分钟' },
    { id: 'b3', name: '豆浆鸡蛋组合', detail: '无糖豆浆 300ml + 茶叶蛋 1 个 + 蒸红薯 150g', kcal: 380, protein: 22, from: '中式减脂餐' }
  ],
  lunch: [
    { id: 'l1', name: '鸡胸肉糙米碗', detail: '鸡胸 150g + 糙米 100g + 西兰花 + 胡萝卜 + 少油快炒', kcal: 550, protein: 45, from: '博主同款便当' },
    { id: 'l2', name: '牛肉荞麦面', detail: '瘦牛肉 120g + 荞麦面 80g + 青菜 + 少许辣油', kcal: 580, protein: 38, from: '外食也能瘦' },
    { id: 'l3', name: '虾仁藜麦沙拉', detail: '虾仁 150g + 藜麦 60g + 生菜 + 圣女果 + 油醋汁', kcal: 450, protein: 36, from: '轻食店平替' }
  ],
  dinner: [
    { id: 'd1', name: '清蒸鱼套餐', detail: '鲈鱼 150g + 杂粮饭 80g + 清炒菠菜', kcal: 480, protein: 40, from: '高蛋白低负担' },
    { id: 'd2', name: '鸡胸蔬菜暖汤', detail: '鸡胸 120g + 冬瓜 + 豆腐 + 金针菇，一锅炖', kcal: 380, protein: 35, from: '晚间减脂首选' },
    { id: 'd3', name: '牛排轻食沙拉', detail: '西冷 120g + 混合生菜 + 玉米粒 + 小番茄', kcal: 520, protein: 38, from: '练腿日犒劳餐' }
  ],
  snack: [
    { id: 's1', name: '希腊酸奶 + 坚果', detail: '无糖希腊酸奶 100g + 混合坚果 10g', kcal: 180, protein: 12, from: '下午加餐' },
    { id: 's2', name: '香蕉 + 水煮蛋', detail: '训练前 30 分钟吃，供能不空腹', kcal: 150, protein: 8, from: '练前标配' },
    { id: 's3', name: '蛋白粉 + 半根香蕉', detail: '一勺蛋白粉 + 半根香蕉，练后 30 分钟内', kcal: 160, protein: 25, from: '练后修复' }
  ]
}

const BADGES = [
  { id: 'first', icon: '🌱', name: '初次训练', desc: '完成第一次训练打卡' },
  { id: 'streak7', icon: '🔥', name: '七日不辍', desc: '连续打卡 7 天' },
  { id: 'streak30', icon: '⚡', name: '三十而立', desc: '连续打卡 30 天' },
  { id: 'total30', icon: '🏆', name: '三十次训练', desc: '累计完成 30 次训练' },
  { id: 'video5', icon: '🎬', name: '记录生活', desc: '保存 5 条训练视频' },
  { id: 'water', icon: '💧', name: '喝饱了', desc: '单日饮水达成 8 杯' },
  { id: 'body7', icon: '📈', name: '持续追踪', desc: '记录 7 次身体数据' }
]
