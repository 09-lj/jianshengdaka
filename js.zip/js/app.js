// ============ 应用框架：hash 路由 + 全局 UI ============

const App = {
  views: {},            // name -> { render(el, params), onLeave() }
  current: null,       // 当前视图名
  _leaveFn: null,      // 离开当前视图时的清理函数

  TABS: [
    { path: 'home',    name: '首页', icon: '🏠' },
    { path: 'train',   name: '训练', icon: '🏋️' },
    { path: 'media',   name: '视频', icon: '🎬' },
    { path: 'diet',    name: '饮食', icon: '🥗' },
    { path: 'mine',    name: '我的', icon: '😊' }
  ],

  // 顶栏标题（非 tab 页也给出标题与返回）
  TITLES: {
    home: '炼打卡',
    train: '本周训练',
    media: '视频库',
    diet: '减脂饮食',
    mine: '我的',
    'train-run': '开始训练',
    exercise: '动作详情',
    review: 'AI 动作审查',
    calendar: '打卡日历',
    diary: '训练日记',
    settings: '设置',
    about: '关于'
  },

  // ---------- 路由 ----------
  go(path) {
    location.hash = '#/' + path
  },

  back() {
    history.length > 1 ? history.back() : this.go('home')
  },

  parseHash() {
    const h = location.hash.replace(/^#\/?/, '')
    const [path, query] = h.split('?')
    const params = {}
    if (query) query.split('&').forEach(kv => {
      const [k, v] = kv.split('=')
      if (k) params[decodeURIComponent(k)] = decodeURIComponent(v || '')
    })
    return { path: path || 'home', params }
  },

  route() {
    const { path, params } = this.parseHash()
    const view = this.views[path] || this.views.home

    // 清理上一个视图（计时器等）
    if (this._leaveFn) { try { this._leaveFn() } catch (e) { } this._leaveFn = null }

    // 顶栏
    const title = this.TITLES[path] || '炼打卡'
    const isTab = this.TABS.some(t => t.path === path)
    document.getElementById('top-title').innerHTML =
      (isTab ? '<span class="logo-fire">🔥</span>' : '<span class="icon-btn" style="display:inline-flex;width:34px;height:34px;font-size:16px;margin-right:2px" onclick="App.back()">‹</span>') +
      esc(title)

    // 视图渲染
    const el = document.getElementById('view')
    el.innerHTML = ''
    this.current = path
    view.render(el, params)
    this._leaveFn = view.onLeave || null

    // tab 高亮
    document.querySelectorAll('#tabbar .tab').forEach(t => {
      t.classList.toggle('on', t.dataset.path === path)
    })
    window.scrollTo(0, 0)
  },

  // ---------- Toast ----------
  _toastTid: null,
  toast(msg) {
    const el = document.getElementById('toast')
    el.textContent = msg
    el.classList.add('show')
    clearTimeout(this._toastTid)
    this._toastTid = setTimeout(() => el.classList.remove('show'), 1800)
  },

  // ---------- Modal ----------
  // opts: { title, body(html), buttons: [{text, cls, cb}], noClose }
  modal(opts) {
    const mask = document.getElementById('modal-mask')
    const m = document.getElementById('modal')
    m.querySelector('.m-title').innerHTML = opts.title || '提示'
    m.querySelector('.m-body').innerHTML = opts.body || ''
    const foot = m.querySelector('.m-foot')
    foot.innerHTML = ''
    ;(opts.buttons || [{ text: '知道了', cls: 'primary' }]).forEach(b => {
      const btn = document.createElement('button')
      btn.className = 'btn ' + (b.cls || '')
      btn.textContent = b.text
      btn.onclick = () => { if (!b.keep) this.closeModal(); b.cb && b.cb() }
      foot.appendChild(btn)
    })
    mask.classList.add('show')
    mask.onclick = (e) => { if (e.target === mask && !opts.noClose) this.closeModal() }
  },

  closeModal() {
    document.getElementById('modal-mask').classList.remove('show')
  },

  // ---------- 抽屉 ----------
  openDrawer() {
    document.getElementById('drawer').classList.add('show')
    document.getElementById('drawer-mask').classList.add('show')
  },

  closeDrawer() {
    document.getElementById('drawer').classList.remove('show')
    document.getElementById('drawer-mask').classList.remove('show')
  },

  // ---------- 视频选择（手机上会弹「拍摄 / 从相册选择」） ----------
  pickVideo() {
    return new Promise(resolve => {
      const input = document.createElement('input')
      input.type = 'file'
      input.accept = 'video/*'
      input.onchange = () => {
        const f = input.files && input.files[0]
        resolve(f || null)
      }
      // 取消选择时无法可靠监听，超时兜底
      input.click()
    })
  },

  // 视频存入本地库（IndexedDB + 元数据）
  async saveVideoFile(file, meta) {
    const id = 'v' + Date.now() + Math.floor(Math.random() * 100)
    await VDB.put(id, file)
    addVideo(Object.assign({
      id,
      name: (meta && meta.name) || '训练视频',
      size: file.size,
      date: todayStr(),
      type: 'checkin',
      starred: false
    }, meta || {}))
    return id
  },

  // 下载备份视频
  async downloadVideo(id, name) {
    const blob = await VDB.get(id)
    if (!blob) { this.toast('视频文件不存在'); return }
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = (name || 'training') + (blob.type && blob.type.indexOf('mp4') >= 0 ? '.mp4' : '.webm')
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    setTimeout(() => URL.revokeObjectURL(url), 3000)
  }
}

window.App = App

// ---------- 启动 ----------
window.addEventListener('hashchange', () => App.route())
window.addEventListener('DOMContentLoaded', () => {
  initSeed()
  App.route()
})
