// ============ 炼打卡 · 网页版 - 本地存储与业务逻辑 ============
// localStorage：打卡/训练/身体/饮水/饮食/AI 配置/视频元数据
// IndexedDB（vdb.js）：视频文件本体

const KEY = {
  PROFILE: 'profile',
  CHECKIN: 'checkin_records',
  TRAIN: 'training_records',
  BODY: 'body_data',
  WATER: 'water_records',
  DIET: 'diet_records',
  VIDEOS: 'local_videos',
  REVIEWS: 'ai_reviews',
  AI: 'ai_config',
  SEEDED: 'seeded'
}

const STORAGE_LIMIT = 1024 * 1024 * 1024 // 1GB 视频提醒阈值

function get(key, def) {
  try {
    const raw = localStorage.getItem(key)
    if (raw === null || raw === undefined || raw === '') return def
    return JSON.parse(raw)
  } catch (e) {
    return def
  }
}

function set(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)) } catch (e) { /* 满 */ }
}

function rm(key) {
  try { localStorage.removeItem(key) } catch (e) { }
}

// ---------- 初始化 ----------
function initSeed() {
  if (get(KEY.SEEDED, false)) return
  set(KEY.PROFILE, {
    nickname: '健身新人',
    gender: 'male',
    targetKcal: 1800,
    targetProtein: 120,
    waterGoal: 8
  })
  set(KEY.SEEDED, true)
}

// ---------- 用户档案 ----------
function getProfile() { return get(KEY.PROFILE, {}) }

function updateProfile(patch) {
  const p = getProfile()
  set(KEY.PROFILE, Object.assign({}, p, patch))
}

// ---------- 周计划 ----------
function getPlanByDate(dateStr) {
  return PLAN[weekDayOf(dateStr)]
}
function getTodayPlan() { return getPlanByDate(todayStr()) }

// 全部动作的索引表（AI 审查选择动作用）
function getAllExercises() {
  const list = []
  PLAN.forEach(p => (p.exercises || []).forEach(ex => list.push(ex)))
  return list
}

// ---------- 打卡 ----------
function getCheckin(dateStr) {
  const all = get(KEY.CHECKIN, {})
  return all[dateStr] || null
}

function doCheckin(dateStr, info) {
  const all = get(KEY.CHECKIN, {})
  all[dateStr] = info
  set(KEY.CHECKIN, all)
}

function isTodayChecked() {
  const plan = getTodayPlan()
  if (plan.type === 'rest') return true
  return !!getCheckin(todayStr())
}

// 连续打卡：训练日(一三五)与拉伸日(六)需打卡，休息日(二/四/日)自动通过
function getStreak() {
  const checkins = get(KEY.CHECKIN, {})
  let streak = 0
  let ds = todayStr()
  const todayPlan = PLAN[weekDayOf(ds)]
  const todayDone = todayPlan.type === 'rest' || !!checkins[ds]
  if (!todayDone) ds = addDays(ds, -1) // 今天还没练不惩罚，从昨天算
  for (let i = 0; i < 730; i++) {
    const plan = PLAN[weekDayOf(ds)]
    if (plan.type === 'rest') { ds = addDays(ds, -1); continue }
    if (checkins[ds]) {
      streak++
      ds = addDays(ds, -1)
    } else break
  }
  return streak
}

// 本周（周一起）：应练天数与已完成数
function getWeekProgress() {
  const checkins = get(KEY.CHECKIN, {})
  const today = todayStr()
  const dow = weekDayOf(today)
  const mondayOffset = dow === 0 ? -6 : 1 - dow
  let total = 0, done = 0
  for (let i = 0; i < 7; i++) {
    const ds = addDays(today, mondayOffset + i)
    const plan = PLAN[weekDayOf(ds)]
    if (plan.type !== 'rest') {
      total++
      if (checkins[ds]) done++
    }
  }
  return { total, done }
}

// ---------- 训练记录 ----------
function getTrainRecord(dateStr) {
  const all = get(KEY.TRAIN, {})
  return all[dateStr] || null
}

function saveTrainRecord(dateStr, record) {
  const all = get(KEY.TRAIN, {})
  all[dateStr] = record
  set(KEY.TRAIN, all)
}

function getExerciseHistory(exId, excludeDate) {
  const all = get(KEY.TRAIN, {})
  const dates = Object.keys(all).sort().reverse()
  for (const ds of dates) {
    if (ds === excludeDate) continue
    const rec = all[ds]
    const ex = (rec.exercises || []).find(e => e.id === exId)
    if (ex && ex.sets && ex.sets.length > 0) return { date: ds, sets: ex.sets }
  }
  return null
}

// 渐进超负荷：上次全部组达标 → 上肢 +2.5kg / 下肢 +5kg
function suggestNextWeight(ex, excludeDate) {
  const hist = getExerciseHistory(ex.id, excludeDate)
  if (!hist || !ex.male) return null
  const valid = hist.sets.every(s => s.reps >= ex.reps)
  if (!valid) return null
  const lastWeight = Math.max.apply(null, hist.sets.map(s => s.weight || 0))
  if (!lastWeight) return null
  const legIds = ['leg-press', 'hip-thrust', 'leg-curl', 'db-lunge']
  const step = legIds.indexOf(ex.id) >= 0 ? 5 : 2.5
  return { lastWeight, nextWeight: Math.round((lastWeight + step) * 10) / 10 }
}

// ---------- 训练视频（元数据在 localStorage，本体在 IndexedDB） ----------
function getVideos() { return get(KEY.VIDEOS, []) }

function addVideo(item) {
  const list = getVideos()
  list.unshift(item)
  set(KEY.VIDEOS, list)
}

// 删除：元数据 + blob 一起删
async function deleteVideo(id) {
  const list = getVideos().filter(v => v.id !== id)
  set(KEY.VIDEOS, list)
  await VDB.del(id)
  deleteReview(id)
}

function toggleVideoStar(id) {
  const list = getVideos().map(v => v.id === id ? Object.assign({}, v, { starred: !v.starred }) : v)
  set(KEY.VIDEOS, list)
}

function totalVideoSize() {
  return getVideos().reduce((s, v) => s + (v.size || 0), 0)
}

// 一键清理：删 N 天前且未星标的视频（含 blob），返回被删列表
async function cleanOldVideos(days) {
  const limit = addDays(todayStr(), -days)
  const keep = [], removed = []
  for (const v of getVideos()) {
    if (v.date < limit && !v.starred) {
      removed.push(v)
      await VDB.del(v.id)
    } else keep.push(v)
  }
  set(KEY.VIDEOS, keep)
  return removed
}

// 实际占用：以视频元数据累加为准（最贴近用户认知），浏览器估算仅作兜底
async function getStorageUsage() {
  const byMeta = totalVideoSize()
  if (byMeta > 0) return byMeta
  try {
    const est = await navigator.storage.estimate()
    if (est && est.usage) return est.usage
  } catch (e) { }
  return 0
}

async function isStorageNearLimit() {
  return (await getStorageUsage()) > STORAGE_LIMIT
}

// ---------- 身体数据 ----------
function getBodyList() { return get(KEY.BODY, []) }

function addBodyRecord(rec) {
  const list = getBodyList()
  const same = list.findIndex(b => b.date === rec.date)
  if (same >= 0) list[same] = rec
  else list.push(rec)
  list.sort((a, b) => a.date < b.date ? -1 : 1)
  set(KEY.BODY, list)
}

// ---------- 饮水 ----------
function getWaterToday() {
  const all = get(KEY.WATER, {})
  return all[todayStr()] || 0
}

function setWaterCups(n) {
  const all = get(KEY.WATER, {})
  all[todayStr()] = Math.max(0, Math.min(20, n))
  set(KEY.WATER, all)
  return all[todayStr()]
}

function getWaterMax() {
  const all = get(KEY.WATER, {})
  let max = 0
  Object.keys(all).forEach(k => { if (all[k] > max) max = all[k] })
  return max
}

// ---------- 饮食记录 ----------
function getDietToday() {
  const all = get(KEY.DIET, {})
  return all[todayStr()] || []
}

function addDietLog(mealItem) {
  const all = get(KEY.DIET, {})
  const t = todayStr()
  const arr = all[t] || []
  arr.push(mealItem)
  all[t] = arr
  set(KEY.DIET, all)
}

function removeDietLog(index) {
  const all = get(KEY.DIET, {})
  const t = todayStr()
  const arr = all[t] || []
  arr.splice(index, 1)
  all[t] = arr
  set(KEY.DIET, all)
}

// ---------- 统计 / 徽章 ----------
function getStats() {
  const checkins = get(KEY.CHECKIN, {})
  const trainDates = Object.keys(checkins).filter(k => checkins[k].type === 'train')
  const trainCount = trainDates.length
  const lastTrain = trainDates.sort().pop() || null
  return {
    streak: getStreak(),
    totalTrain: trainCount,
    lastTrain,
    videos: getVideos().length,
    videoSize: totalVideoSize(),
    bodyCount: getBodyList().length,
    waterMax: getWaterMax()
  }
}

function calcBadges() {
  const s = getStats()
  return BADGES.map(b => {
    let got = false
    if (b.id === 'first') got = s.totalTrain >= 1
    if (b.id === 'streak7') got = s.streak >= 7
    if (b.id === 'streak30') got = s.streak >= 30
    if (b.id === 'total30') got = s.totalTrain >= 30
    if (b.id === 'video5') got = s.videos >= 5
    if (b.id === 'water') got = s.waterMax >= 8
    if (b.id === 'body7') got = s.bodyCount >= 7
    return Object.assign({}, b, { got })
  })
}

// ---------- 日历（月视图） ----------
function getMonthCheckins(year, month) {
  const checkins = get(KEY.CHECKIN, {})
  const days = new Date(year, month, 0).getDate()
  const res = []
  for (let d = 1; d <= days; d++) {
    const ds = year + '-' + (month < 10 ? '0' + month : month) + '-' + (d < 10 ? '0' + d : d)
    res.push({ date: ds, day: d, checkin: !!checkins[ds] })
  }
  return res
}

// ---------- AI 配置 ----------
function getAiConfig() {
  const def = {
    vendor: 'qwen',
    baseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1',
    model: 'qwen-vl-max',
    apiKey: ''
  }
  return Object.assign(def, get(KEY.AI, {}))
}

function updateAiConfig(patch) {
  const c = getAiConfig()
  set(KEY.AI, Object.assign({}, c, patch))
}

// ---------- AI 审查报告 ----------
function getReviews() { return get(KEY.REVIEWS, {}) }

function getReview(videoId) {
  const all = getReviews()
  return all[videoId] || null
}

function saveReview(videoId, report, exInfo) {
  const all = getReviews()
  all[videoId] = Object.assign({ at: Date.now(), exInfo: exInfo || null }, report)
  set(KEY.REVIEWS, all)
}

function deleteReview(videoId) {
  const all = getReviews()
  delete all[videoId]
  set(KEY.REVIEWS, all)
}

// ---------- 清除所有数据（含视频 blob） ----------
async function clearAll() {
  Object.keys(KEY).forEach(k => { if (k !== 'SEEDED') rm(KEY[k]) })
  await VDB.clear()
  initSeed()
}
