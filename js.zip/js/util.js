// ============ 通用工具 ============

function pad(n) {
  return n < 10 ? '0' + n : '' + n
}

// 'YYYY-MM-DD'
function fmtDate(d) {
  return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate())
}

function todayStr() {
  return fmtDate(new Date())
}

function addDays(dateStr, n) {
  const d = new Date(dateStr + 'T00:00:00')
  d.setDate(d.getDate() + n)
  return fmtDate(d)
}

// 0-6，0=周日
function weekDayOf(dateStr) {
  return new Date(dateStr + 'T00:00:00').getDay()
}

const DAY_NAMES = ['周日', '周一', '周二', '周三', '周四', '周五', '周六']

function dayName(dateStr) {
  return DAY_NAMES[weekDayOf(dateStr)]
}

// 友好日期：'9月13日'
function friendly(dateStr) {
  const p = dateStr.split('-')
  return (+p[1]) + '月' + (+p[2]) + '日'
}

function formatSize(bytes) {
  if (!bytes || bytes <= 0) return '0MB'
  const mb = bytes / (1024 * 1024)
  if (mb < 1) return (bytes / 1024).toFixed(0) + 'KB'
  if (mb < 1024) return mb.toFixed(1).replace(/\.0$/, '') + 'MB'
  return (mb / 1024).toFixed(2) + 'GB'
}

// 'YYYY-MM'
function monthKey(dateStr) {
  return dateStr.slice(0, 7)
}

// HTML 转义
function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;')
}
